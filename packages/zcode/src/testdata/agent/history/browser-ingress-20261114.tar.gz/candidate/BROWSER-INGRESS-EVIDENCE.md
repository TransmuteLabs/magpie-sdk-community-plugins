# Closed-socket admission in the packaged browser fixture

2026-11-14. This is a verification-only follow-up to the two preserved
browser RED packets. The ordinary package stays 0.13.1/API1.9, with
provider, controller, agent and UI together. Production Go/TS, native
libraries, ZIP, source-lock, dependencies and the shared SDK are unchanged.

## Cause and historical boundary

The first rendered case completed native synthetic sign-in and a selected
account read, but failed its unchanged `assert not vendor.errors,
vendor.errors` on three sockets whose live process owner was unavailable.
Its receipt remains
`5be4223d40e9dc3987163634c6c3fc6a02818243a7fbf2b692643034a087b018`;
ports43908,43914,43988 remain historically unattributed.

The subsequent, separately preserved diagnostic case captured the three
new sockets at connect time. They came from Devin PIDs1931132 and1931200,
both direct children of GUI Magpie PID1930709, under fixture PID1930006.
Exact tuples, PID/TID/startTicks, lineage and socket inodes establish that
run's sender. Ingress looked for owners after the sockets had closed:
`socket_process_unknown` at `ss_owners`, FIN-WAIT, inode0 and no users.
One live inode vanished during lookup; two were already zero. This
establishes a fixture attribution race, without establishing a production
ZCode bug or assigning the earlier three senders.

That diagnostic run remains RED. Its receipt is
`57795c716cc69f34dbf6abf2f56521589369ed08da04d9407cde74cb83b15786`
at `usbox:/tmp/magpie-zcode-browser-attribution-f7-ADrRLL7M/`.
No historical packet was edited.

## Narrow repair and proof trust

`testdata/agent/ingress.py` retains its live tuple/inode/PID/FD/ancestry
check. A missing live owner can use the new `connect_ledger.py` reader
only when the fixture was started by its credentialled external guard.
Every guarded owned admission, including the ordinary live-owner path,
consumes exactly one proof. The same record cannot subsequently authorize
a fallback or another connection.

The existing external seccomp broker is retained as
`testdata/agent/connect_guard.c`. Its syscall filter, socket lookup,
release, loopback policy and rooted Unix policy functions are byte-identical
to the pinned diagnostic guard. It still denies non-loopback networking
and leaves native root ownership unchanged. The only new transport is
the private proof channel from that broker to its direct fixture child:

- A pre-fork Unix SOCK_SEQPACKET pair carries complete records.
  SO_PEERCRED binds the peer to the fixture's actual guardian parent,
  UID/GID and captured process startTicks. Each received packet must
  have matching kernel SCM_CREDENTIALS.
- The child closes the writer endpoint. The guardian disables dumpability
  to prevent descendants from acquiring its private descriptors. The
  reader immediately marks its inherited endpoint close-on-exec; host,
  native and browser children do not inherit it. Its write direction is
  shut down.
- The broker captures the stopped caller's PID/TID and startTicks,
  rechecks identities, and publishes the exact tuple, inode, result and
  linked ancestry before releasing its socket reference and returning
  from connect. Cached records are immutable bytes from that channel.
- Admission requires a unique tuple, bounded monotonic connect/admission
  times, the exact fixture PID/parent/startTicks in a linked ancestry,
  stable caller identity, and matching inode whenever available.
  Successful consumption is atomic across both owner paths. Records
  before listener setup, older than five seconds, missing, conflicting,
  ambiguous, foreign or already consumed fail closed.

The private JSONL file is an audit copy, never admission authority.
Its creation is exclusive, no-follow and mode0600 in a private packet.
Files from an earlier run, forged headers and a process name cannot grant
admission. New ingress logs omit headers and redact private polling
paths. Positively identified outside processes remain rejected before
HTTP, while unresolved ingress still appends a vendor error. Owned
unexpected GET/POST requests still reach the original strict vendor.

This is fixture process attribution, not a new SDK security contract or
a sandbox for arbitrary code running inside the trusted Python verifier.

## Scoped usbox regressions

Remote root:
`usbox:/tmp/magpie-zcode-ingress-admission-f7-rgsG8ph9/`.
The immutable `source-final/` packet contains the tested admission
sources; `source-browser/` adds only the final browser proof receipt
collection. Reader, broker and admission tests are identical between them.

| Gate | Terminal result |
| --- | --- |
| Original live ingress/strict GET+POST/foreign/missing-owner tests | 4 PASS,2.284s |
| Closed-child, inode conflict, single-use, channel and validation tests | 7 PASS,0.949s |
| Same final closed-child regression with the old ingress | RED,1 assertion failure,0.099s |
| Remove only proof consumption | RED,2 assertion failures,0.654s |
| Python AST, Node syntax, C `-Wall -Wextra -Werror` | PASS |
| Existing deny-policy function byte comparison | PASS |

The real closed-child test blocks admission until the client has written
its request, closed the socket and exited; its PID is absent before the
barrier releases. It then requires the original strict HTTP handler to
receive exactly one GET `/updates` through closed-socket admission.
The old owner code fails on a vendor error at that same boundary.

Actual admission negatives inject missing, ambiguous, stale, caller
startTicks mismatch, foreign lineage, failed identity capture, missing
inode and failed-connect records into the authenticated cache in the test
only, and separately conflict the known socket inode. All fail before
HTTP. The original 14 correlation-control categories are retained across
these tests and the original foreign-process test, including the three
historical unknown tuples. Additional checks cover broken ancestry,
unstable identities and explicit expiry.

Closed-to-closed and live-to-fallback replay are tested through
`verify_request`, requiring the second admission to fail. Removing the
single consumption statement makes both fail with `[True, True]` instead
of `[True, False]`. Regular-file/self-authored channels, inherited writer
access, guardian descriptor access and reader inheritance through exec
are also rejected or checked.

The final fixture patch SHA256 before the browser case is
`bf4b3804a0578441a311a729e101aeec3049f1a6cae6126925edbeee3f14ba78`.
Exact file hashes, logs and negative-control source are beside the
snapshots. The earlier `old-code.log` and v1 evidence are preserved too.

## Exact browser inputs and limits

| Input | Immutable pin |
| --- | --- |
| Host physical tree | `f7f26b2d5ee5388a089ab07a72f7372ed0068971` |
| Host binary SHA256 | `9ddc4e4a076dbcc119e71b5c3b140253e8c419f3278dfadc5d8cdadd59c20adb` |
| Full ZIP SHA256 | `45d1e73c30379b5911bc1c47c64928828f12988692c66b7611be70e7f681125b` |
| Production native library SHA256 | `1b408ffbb73a7db0874d9321777947c5eb89d25c66e2c089fa84b3f12c686bc3` |
| Reused synthetic-endpoint library SHA256 | `57c6c01915dd6b46cde2c031394f6ee5a7972023f0887021930e8a6183122327` |
| Unchanged browser driver SHA256 | `cdc65960416c14bdb13da8279e0e7c4dbff49b67f3e0757d5f22b84789bc3e36` |

The authorized post-fix validation is one existing synthetic case in
pinned Chromium151.0.7922.34 / Playwright1.62.1. It uses the actual packaged
UI through the ordinary GUI parent, with the retained endpoint-overlaid
native library. It does not rebuild or retest the later shared host.
Account identity/generation, one auth flow, one selected-account read,
empty execution ledger, exact served assets, sandbox isolation and secret
non-disclosure remain explicit assertions.

The browser terminal result and final receipt are pending at this
documentation checkpoint. No overall browser pass is claimed here.
Actual installed ZCode, live vendors/accounts, Darwin/Windows, automatic
DB/WAL capture and financial resume remain outside this synthetic case.
