#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/audit.h>
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <poll.h>
#include <signal.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

struct held_socket {
    int descriptor;
    ino_t inode;
    int domain;
};

static struct held_socket sockets[4096];
static unsigned allowed_connects, allowed_binds, denied_operations;
static unsigned allowed_unix_connects, allowed_unix_binds, proof_sequence;
static int ipc_root, proof_channel;
static FILE *connect_diagnostics;
static const char *ipc_path = "/tmp/magpie-gui-pinned-browsers-9sjvuwee/tmp";

static void fail(const char *operation) {
    perror(operation);
    exit(125);
}

static unsigned long long clock_ns(clockid_t clock) {
    struct timespec value;
    if (clock_gettime(clock, &value)) fail("diagnostic clock");
    return (unsigned long long)value.tv_sec * 1000000000ULL + (unsigned long long)value.tv_nsec;
}

static int process_identity(pid_t process, pid_t *parent, unsigned long long *started) {
    char path[80], buffer[4096];
    snprintf(path, sizeof(path), "/proc/%d/stat", process);
    FILE *input = fopen(path, "r");
    if (!input) return -1;
    char *result = fgets(buffer, sizeof(buffer), input);
    fclose(input);
    if (!result) return -1;
    char *tail = strrchr(buffer, ')');
    if (!tail || tail[1] != ' ') return -1;
    char *save = NULL;
    int field = 3;
    for (char *token = strtok_r(tail + 2, " ", &save); token; token = strtok_r(NULL, " ", &save), field++) {
        if (field == 4) *parent = (pid_t)strtol(token, NULL, 10);
        if (field == 22) {
            *started = strtoull(token, NULL, 10);
            return 0;
        }
    }
    return -1;
}

static pid_t thread_group(pid_t thread) {
    char path[80], buffer[256];
    snprintf(path, sizeof(path), "/proc/%d/status", thread);
    FILE *input = fopen(path, "r");
    if (!input) return 0;
    pid_t process = 0;
    while (fgets(buffer, sizeof(buffer), input))
        if (sscanf(buffer, "Tgid: %d", &process) == 1) break;
    fclose(input);
    return process;
}

static void json_string(FILE *output, const char *value) {
    fputc('"', output);
    for (const unsigned char *cursor = (const unsigned char *)value; *cursor; cursor++) {
        if (*cursor == '"' || *cursor == '\\') {
            fputc('\\', output);
            fputc(*cursor, output);
        } else if (*cursor < 32) {
            fprintf(output, "\\u%04x", *cursor);
        } else {
            fputc(*cursor, output);
        }
    }
    fputc('"', output);
}

static void trace_connect(const struct seccomp_notif *request, const struct held_socket *held,
                          const struct sockaddr_in *target, int result, int failure,
                          unsigned long long started) {
    struct sockaddr_in local = {0};
    socklen_t length = sizeof(local);
    int local_result = getsockname(held->descriptor, (struct sockaddr *)&local, &length);
    char local_ip[INET_ADDRSTRLEN] = "", target_ip[INET_ADDRSTRLEN] = "";
    if (local_result == 0) inet_ntop(AF_INET, &local.sin_addr, local_ip, sizeof(local_ip));
    inet_ntop(AF_INET, &target->sin_addr, target_ip, sizeof(target_ip));
    pid_t process = thread_group((pid_t)request->pid), parent = 0, thread_parent = 0;
    unsigned long long ticks = 0, thread_ticks = 0;
    int identity_result = process_identity(process, &parent, &ticks);
    if (process_identity((pid_t)request->pid, &thread_parent, &thread_ticks))
        identity_result = -1;
    char *buffer = NULL;
    size_t size = 0;
    FILE *output = open_memstream(&buffer, &size);
    if (!output) fail("connect proof buffer");
    fprintf(output,
            "{\"kind\":\"connect\",\"sequence\":%u,\"wallNs\":%llu,\"monotonicNs\":%llu,"
            "\"connectStartMonotonicNs\":%llu,"
            "\"tid\":%u,\"pid\":%d,\"ppid\":%d,\"startTicks\":%llu,\"tidStartTicks\":%llu,"
            "\"identityResult\":%d,\"fd\":%llu,\"inode\":%llu,\"result\":%d,\"errno\":%d,"
            "\"local\":[\"%s\",%u],\"remote\":[\"%s\",%u],\"lineage\":[",
            ++proof_sequence, clock_ns(CLOCK_REALTIME), clock_ns(CLOCK_MONOTONIC), started,
            request->pid, process, parent, ticks, thread_ticks, identity_result,
            (unsigned long long)request->data.args[0], (unsigned long long)held->inode,
            result, failure, local_ip, (unsigned)ntohs(local.sin_port), target_ip, (unsigned)ntohs(target->sin_port));
    pid_t current = process;
    for (unsigned depth = 0; current > 0 && depth < 64; depth++) {
        pid_t next = 0;
        unsigned long long current_ticks = 0;
        if (process_identity(current, &next, &current_ticks)) break;
        char path[80], executable[2048];
        snprintf(path, sizeof(path), "/proc/%d/exe", current);
        ssize_t executable_length = readlink(path, executable, sizeof(executable) - 1);
        executable[executable_length >= 0 ? executable_length : 0] = '\0';
        fprintf(output, "%s{\"pid\":%d,\"ppid\":%d,\"startTicks\":%llu,\"executable\":",
                depth ? "," : "", current, next, current_ticks);
        json_string(output, executable);
        fputc('}', output);
        if (next == current) break;
        current = next;
    }
    pid_t checked_parent = 0;
    unsigned long long checked_ticks = 0, checked_thread_ticks = 0;
    int stable = process_identity(process, &checked_parent, &checked_ticks) == 0
        && checked_parent == parent && checked_ticks == ticks
        && process_identity((pid_t)request->pid, &checked_parent, &checked_thread_ticks) == 0
        && checked_thread_ticks == thread_ticks
        && thread_group((pid_t)request->pid) == process;
    fprintf(output, "],\"stable\":%s}\n", stable ? "true" : "false");
    if (fclose(output)) fail("finish connect proof");
    if (fwrite(buffer, 1, size, connect_diagnostics) != size || fflush(connect_diagnostics))
        fail("flush connect diagnostics");
    if (send(proof_channel, buffer, size, MSG_NOSIGNAL) != (ssize_t)size)
        fail("publish connect proof");
    free(buffer);
}

static void pass_descriptor(int channel, int descriptor) {
    char value = 0;
    struct iovec vector = {.iov_base = &value, .iov_len = 1};
    char control[CMSG_SPACE(sizeof(int))] = {0};
    struct msghdr message = {.msg_iov = &vector, .msg_iovlen = 1,
                            .msg_control = control, .msg_controllen = sizeof(control)};
    struct cmsghdr *header = CMSG_FIRSTHDR(&message);
    header->cmsg_level = SOL_SOCKET;
    header->cmsg_type = SCM_RIGHTS;
    header->cmsg_len = CMSG_LEN(sizeof(int));
    memcpy(CMSG_DATA(header), &descriptor, sizeof(descriptor));
    if (sendmsg(channel, &message, 0) != 1) fail("send listener");
}

static int receive_descriptor(int channel) {
    char value;
    struct iovec vector = {.iov_base = &value, .iov_len = 1};
    char control[CMSG_SPACE(sizeof(int))] = {0};
    struct msghdr message = {.msg_iov = &vector, .msg_iovlen = 1,
                            .msg_control = control, .msg_controllen = sizeof(control)};
    if (recvmsg(channel, &message, MSG_CMSG_CLOEXEC) != 1) fail("receive listener");
    struct cmsghdr *header = CMSG_FIRSTHDR(&message);
    if (!header || header->cmsg_level != SOL_SOCKET || header->cmsg_type != SCM_RIGHTS)
        fail("missing listener");
    int descriptor;
    memcpy(&descriptor, CMSG_DATA(header), sizeof(descriptor));
    return descriptor;
}

static void filter_child(void) {
    struct sock_filter instructions[] = {
        BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, arch)),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, AUDIT_ARCH_X86_64, 1, 0),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),
        BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, nr)),
        BPF_JUMP(BPF_JMP | BPF_JSET | BPF_K, 0x40000000, 0, 1),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_socket, 5, 0),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_connect, 4, 0),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_bind, 3, 0),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_close, 2, 0),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_io_uring_setup, 2, 0),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_USER_NOTIF),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ERRNO | EPERM),
    };
    struct sock_fprog program = {.len = sizeof(instructions) / sizeof(instructions[0]), .filter = instructions};
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) fail("no new privileges");
    int listener = syscall(SYS_seccomp, SECCOMP_SET_MODE_FILTER, SECCOMP_FILTER_FLAG_NEW_LISTENER, &program);
    if (listener < 0) fail("seccomp listener");
    pass_descriptor(3, listener);
}

static struct held_socket *find_socket(pid_t process, int descriptor) {
    char path[80];
    struct stat status;
    snprintf(path, sizeof(path), "/proc/%d/fd/%d", process, descriptor);
    if (stat(path, &status) || !S_ISSOCK(status.st_mode)) return NULL;
    for (size_t index = 0; index < sizeof(sockets) / sizeof(sockets[0]); index++)
        if (sockets[index].inode == status.st_ino) return &sockets[index];
    return NULL;
}

static void release_socket(struct held_socket *held) {
    close(held->descriptor);
    held->inode = 0;
}

static int rooted_unix_address(const struct sockaddr_un *address, struct sockaddr_un *rooted, int connecting) {
    size_t prefix = strlen(ipc_path);
    if (address->sun_family != AF_UNIX ||
        !memchr(address->sun_path, '\0', sizeof(address->sun_path)) ||
        strncmp(address->sun_path, ipc_path, prefix) || address->sun_path[prefix] != '/')
        return -1;
    char relative[sizeof(address->sun_path)];
    snprintf(relative, sizeof(relative), "%s", address->sun_path + prefix + 1);
    char *leaf = strrchr(relative, '/');
    int parent = fcntl(ipc_root, F_DUPFD_CLOEXEC, 0);
    if (parent < 0) return -1;
    if (leaf) {
        *leaf++ = '\0';
        char *save = NULL;
        for (char *segment = strtok_r(relative, "/", &save); segment; segment = strtok_r(NULL, "/", &save)) {
            if (!strcmp(segment, ".") || !strcmp(segment, "..")) {
                close(parent);
                return -1;
            }
            int next = openat(parent, segment, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
            close(parent);
            if (next < 0) return -1;
            parent = next;
        }
    } else {
        leaf = relative;
    }
    if (!*leaf || !strcmp(leaf, ".") || !strcmp(leaf, "..")) {
        close(parent);
        return -1;
    }
    rooted->sun_family = AF_UNIX;
    int length;
    if (connecting) {
        int target = openat(parent, leaf, O_PATH | O_NOFOLLOW | O_CLOEXEC);
        close(parent);
        struct stat target_status;
        if (target < 0) return -1;
        if (fstat(target, &target_status) || !S_ISSOCK(target_status.st_mode)) {
            close(target);
            return -1;
        }
        parent = target;
        length = snprintf(rooted->sun_path, sizeof(rooted->sun_path), "/proc/self/fd/%d", parent);
    } else {
        length = snprintf(rooted->sun_path, sizeof(rooted->sun_path), "/proc/self/fd/%d/%s", parent, leaf);
    }
    if (length < 0 || (size_t)length >= sizeof(rooted->sun_path)) {
        close(parent);
        return -1;
    }
    return parent;
}

static void handle(int listener, const struct seccomp_notif *request) {
    struct seccomp_notif_resp response = {.id = request->id};
    int descriptor = (int)request->data.args[0];
    if (request->data.nr == SYS_socket) {
        int domain = descriptor;
        int type = (int)request->data.args[1];
        int protocol = (int)request->data.args[2];
        int base_type = type & ~(SOCK_CLOEXEC | SOCK_NONBLOCK);
        if (!((domain == AF_INET && base_type == SOCK_STREAM &&
               (protocol == 0 || protocol == IPPROTO_TCP)) ||
              (domain == AF_UNIX && protocol == 0 &&
               (base_type == SOCK_STREAM || base_type == SOCK_DGRAM || base_type == SOCK_SEQPACKET)))) {
            response.error = -EPERM;
            denied_operations++;
        } else {
            struct held_socket *held = NULL;
            for (size_t index = 0; index < sizeof(sockets) / sizeof(sockets[0]); index++)
                if (!sockets[index].inode) { held = &sockets[index]; break; }
            if (!held) fail("socket budget");
            int local = socket(domain, type, protocol);
            if (local < 0) {
                response.error = -errno;
            } else {
                struct stat status;
                if (fstat(local, &status)) fail("socket identity");
                held->descriptor = local;
                held->inode = status.st_ino;
                held->domain = domain;
                struct seccomp_notif_addfd addition = {
                    .id = request->id, .flags = SECCOMP_ADDFD_FLAG_SEND,
                    .srcfd = local, .newfd_flags = (type & SOCK_CLOEXEC) ? O_CLOEXEC : 0,
                };
                if (ioctl(listener, SECCOMP_IOCTL_NOTIF_ADDFD, &addition) >= 0) return;
                int failure = errno;
                release_socket(held);
                if (failure == ENOENT) return;
                errno = failure;
                fail("inject socket");
            }
        }
    } else {
        struct held_socket *held = find_socket(request->pid, descriptor);
        if (request->data.nr == SYS_close) {
            if (held) release_socket(held);
            response.flags = SECCOMP_USER_NOTIF_FLAG_CONTINUE;
        } else if (held && held->domain == AF_UNIX) {
            struct sockaddr_un address = {0}, rooted = {0};
            size_t length = request->data.args[2];
            struct iovec local = {.iov_base = &address, .iov_len = length};
            struct iovec remote = {.iov_base = (void *)(uintptr_t)request->data.args[1], .iov_len = length};
            int parent = -1;
            if (length > offsetof(struct sockaddr_un, sun_path) && length <= sizeof(address) &&
                process_vm_readv(request->pid, &local, 1, &remote, 1, 0) == (ssize_t)length)
                parent = rooted_unix_address(&address, &rooted, request->data.nr == SYS_connect);
            if (parent < 0) {
                response.error = -EPERM;
                denied_operations++;
            } else if (ioctl(listener, SECCOMP_IOCTL_NOTIF_ID_VALID, &request->id) == 0) {
                int result;
                if (request->data.nr == SYS_connect) {
                    result = connect(held->descriptor, (struct sockaddr *)&rooted, sizeof(rooted));
                    allowed_unix_connects++;
                } else {
                    result = bind(held->descriptor, (struct sockaddr *)&rooted, sizeof(rooted));
                    allowed_unix_binds++;
                }
                response.error = result < 0 ? -errno : 0;
            } else {
                close(parent);
                release_socket(held);
                return;
            }
            if (parent >= 0) close(parent);
            release_socket(held);
        } else {
            struct sockaddr_in address = {0};
            struct iovec local = {.iov_base = &address, .iov_len = sizeof(address)};
            struct iovec remote = {.iov_base = (void *)(uintptr_t)request->data.args[1], .iov_len = sizeof(address)};
            if (!held || request->data.args[2] != sizeof(address) ||
                process_vm_readv(request->pid, &local, 1, &remote, 1, 0) != sizeof(address) ||
                address.sin_family != AF_INET || address.sin_addr.s_addr != htonl(INADDR_LOOPBACK)) {
                response.error = -EPERM;
                denied_operations++;
            } else if (ioctl(listener, SECCOMP_IOCTL_NOTIF_ID_VALID, &request->id) == 0) {
                int result;
                if (request->data.nr == SYS_connect) {
                    unsigned long long started = clock_ns(CLOCK_MONOTONIC);
                    result = connect(held->descriptor, (struct sockaddr *)&address, sizeof(address));
                    int failure = result < 0 ? errno : 0;
                    trace_connect(request, held, &address, result, failure, started);
                    errno = failure;
                    allowed_connects++;
                } else {
                    result = bind(held->descriptor, (struct sockaddr *)&address, sizeof(address));
                    allowed_binds++;
                }
                response.error = result < 0 ? -errno : 0;
            } else {
                return;
            }
            if (held) release_socket(held);
        }
    }
    if (ioctl(listener, SECCOMP_IOCTL_NOTIF_SEND, &response) < 0 && errno != ENOENT)
        fail("respond to socket operation");
}

int main(int count, char **arguments) {
    if (count < 4) {
        fprintf(stderr, "usage: connect-guard report.json command arguments...\n");
        return 125;
    }
    const char *temporary = getenv("TMPDIR");
    if (!temporary || strcmp(temporary, ipc_path)) fail("owned IPC root environment");
    ipc_root = open(ipc_path, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    struct stat ipc_status;
    if (ipc_root < 0 || fstat(ipc_root, &ipc_status) || ipc_status.st_uid != getuid())
        fail("owned IPC root identity");
    const char *diagnostic_path = getenv("ATTRIBUTION_CONNECT_LOG");
    if (!diagnostic_path) fail("connect diagnostic path");
    int diagnostic_fd = open(diagnostic_path, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
    if (diagnostic_fd < 0) fail("open connect diagnostics");
    connect_diagnostics = fdopen(diagnostic_fd, "w");
    if (!connect_diagnostics) fail("connect diagnostic stream");
    int channels[2], proofs[2], credentials = 1;
    if (socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0, channels)
            || socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0, proofs)
            || setsockopt(proofs[1], SOL_SOCKET, SO_PASSCRED, &credentials, sizeof(credentials))
            || shutdown(proofs[1], SHUT_WR)) fail("control channels");
    pid_t child = fork();
    if (child < 0) fail("fork fixture");
    if (child == 0) {
        close(channels[0]);
        close(proofs[0]);
        close(diagnostic_fd);
        if (dup2(proofs[1], 198) < 0) fail("child proof channel");
        if (setenv("ZCODE_FIXTURE_CONNECT_FD", "198", 1)) fail("proof channel marker");
        close(proofs[1]);
        if (channels[1] != 3 && dup2(channels[1], 3) < 0) fail("child control channel");
        filter_child();
        close(3);
        if (setenv("MAGPIE_OPENCODE_LOOPBACK_GUARD", "seccomp-broker", 1)) fail("guard marker");
        execvp(arguments[2], arguments + 2);
        fail("execute fixture");
    }
    close(channels[1]);
    close(proofs[1]);
    proof_channel = proofs[0];
    if (prctl(PR_SET_DUMPABLE, 0)) fail("protect guardian descriptors");
    int listener = receive_descriptor(channels[0]);
    close(channels[0]);
    int status = 0;
    for (;;) {
        struct pollfd ready = {.fd = listener, .events = POLLIN};
        int result = poll(&ready, 1, 50);
        if (result < 0 && errno != EINTR) fail("poll notification");
        if (result > 0 && (ready.revents & POLLIN)) {
            struct seccomp_notif request = {0};
            if (ioctl(listener, SECCOMP_IOCTL_NOTIF_RECV, &request) == 0) handle(listener, &request);
            else if (errno != ENOENT && errno != EINTR) fail("receive notification");
        }
        pid_t finished = waitpid(child, &status, WNOHANG);
        if (finished == child) break;
        if (finished < 0) fail("join fixture");
    }
    close(listener);
    close(proof_channel);
    for (size_t index = 0; index < sizeof(sockets) / sizeof(sockets[0]); index++)
        if (sockets[index].inode) release_socket(&sockets[index]);
    FILE *report = fopen(arguments[1], "w");
    if (!report) fail("guard report");
    struct stat root;
    if (stat("/", &root)) fail("root ownership");
    fprintf(report, "{\"guard\":\"seccomp-broker\",\"connects\":%u,\"binds\":%u,\"denied\":%u,"
                    "\"unixConnects\":%u,\"unixBinds\":%u,\"proofs\":%u,"
                    "\"networkPointerContinuation\":false,\"unixPointerContinuation\":false,"
                    "\"unixPolicy\":\"owned-tmpdir-openat-nofollow\",\"rootOwnerUID\":%u,\"childExit\":%d}\n",
            allowed_connects, allowed_binds, denied_operations, allowed_unix_connects, allowed_unix_binds,
            proof_sequence, (unsigned)root.st_uid,
            WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status));
    if (fclose(report)) fail("close guard report");
    if (fclose(connect_diagnostics)) fail("close connect diagnostics");
    return WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status);
}
