from collections import Counter
import hashlib
import http.cookiejar
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import urllib.request
import zipfile


sys.dont_write_bytecode = True
root = Path(os.environ["ZCODE_BROWSER_PACKET"])
source = Path(__file__).resolve().parents[2]
parent = Path("/tmp/magpie-sdk-final-base-p2tiu0uf")
previous = Path("/tmp/magpie-zcode-merge221-native-lsmaE5UY")
diagnostic = Path("/tmp/magpie-zcode-browser-attribution-f7-ADrRLL7M")
module = previous / "module"
package = module / "dist/magpie-plugin_linux_amd64.zip"
library = Path("/tmp/magpie-zcode-decisionmodels9-LeI0cmVk/installed-fixtures/zcode-owned-agent-uuq8iz_2/distribution/lib/zcode.so")
host = parent / "magpie"
pasteur = Path("/tmp/magpie-gui-pinned-browsers-9sjvuwee/snapshot-2225702-full-clean")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (root / name).write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def scenario():
    load("zcode_browser_attribution", diagnostic / "attribution.py")
    ingress = load("zcode_browser_ingress", source / "testdata/agent/ingress.py")
    agent = load("zcode_browser_native_fixture", module / "testdata/agent/run.py")
    home = Path(os.environ["HOME"])
    distribution = root / "distribution"
    with zipfile.ZipFile(package) as archive:
        archive.extractall(distribution)
    manifest = json.loads((distribution / "magpie-plugin.json").read_text())
    metadata = json.loads((distribution / "package.json").read_text())
    production_library = digest(distribution / manifest["entry"])
    assert production_library == "1b408ffbb73a7db0874d9321777947c5eb89d25c66e2c089fa84b3f12c686bc3"
    shutil.copy2(library, distribution / manifest["entry"])
    environment = dict(os.environ)
    setup = []

    def cli(*arguments):
        assert arguments[:3] == ("plugin", "sdk", "add") or arguments[:3] == ("plugin", "sdk", "config")
        result = subprocess.run([str(host), *arguments], env=environment, cwd=root,
                                capture_output=True, text=True, timeout=45)
        setup.append({"operation": arguments[2], "exit": result.returncode})
        assert result.returncode == 0, result.stderr[-1500:]
        return result.stdout

    with ingress.owned_vendor(module, root) as vendor:
        observed = agent.observe_vendor(vendor)
        environment.update(
            MAGPIE_ADDR="127.0.0.1:" + str(agent.free_port()),
            MAGPIE_WEB_KEY="synthetic-zcode-render-key",
            MAGPIE_UPDATE_FEED=vendor.origin + "/updates",
            HTTP_PROXY=vendor.origin, HTTPS_PROXY=vendor.origin, NO_PROXY="127.0.0.1,localhost",
        )
        cli("plugin", "sdk", "add", str(distribution))
        config = json.loads(cli("plugin", "sdk", "config", "zcode"))
        cli("plugin", "sdk", "config", "zcode", json.dumps({"dataDir": str(home / "controller")}),
            "--expected", config["version"])
        web_port = agent.free_port()
        origin = "http://127.0.0.1:" + str(web_port)
        with (root / "web.log").open("x") as output:
            process = subprocess.Popen([str(host), "web", "--addr", "127.0.0.1:" + str(web_port), "--no-open"],
                                       env=environment, cwd=root, stdout=output, stderr=subprocess.STDOUT)
            save("host-process.json", {"pid": process.pid, "origin": origin})
            try:
                jar = http.cookiejar.CookieJar()
                opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),
                                                     urllib.request.HTTPCookieProcessor(jar))
                deadline = time.monotonic() + 30
                while True:
                    try:
                        with opener.open(origin + "/?k=synthetic-zcode-render-key", timeout=2) as response:
                            response.read()
                        break
                    except OSError:
                        assert process.poll() is None and time.monotonic() < deadline, "isolated host readiness failed"
                        time.sleep(0.1)
                with opener.open(origin + "/api/plugin-pages", timeout=10) as response:
                    pages = json.loads(response.read())
                assert len(pages) == 1 and pages[0]["name"] == "zcode"
                page = pages[0]
                base = page["url"].rsplit("/", 1)[0]
                page_directory = distribution / Path(metadata["magpie"]["page"]["file"]).parent
                html = (page_directory / "index.html").read_text()
                bridge = "globalThis.__magpieInlined=1;\n" + (parent / "source/internal/gui/pagebridge.js").read_text()
                bundle = (page_directory / "app.bundle.js").read_text()
                style = (page_directory / "style.css").read_text()
                script = lambda body: "<script>" + body.replace("</script", r"<\/script") + "\n</script>"
                for tag, replacement in (
                    ('<script src="_magpie/bridge.js"></script>', script(bridge)),
                    ('<script src="./app.bundle.js" defer></script>', ""),
                    ('<link rel="stylesheet" href="./style.css">', "<style>" + style.replace("</style", r"<\/style") + "</style>"),
                ):
                    assert html.count(tag) == 1
                    html = html.replace(tag, replacement)
                assert html.count("</body>") == 1
                html = html.replace("</body>", script(bundle) + "\n</body>")
                (root / "expected-frame.html").write_text(html)
                assert digest(root / "expected-frame.html") == "3497c8b1bcb005660bf69ca2264bbf5af75ed177ddc2b07e9922d65334b80981"
                save("package-asset-pins.json", {
                    "packageFiles": {name: digest(page_directory / name) for name in ("index.html", "app.bundle.js", "style.css")},
                    "hostBridgeSHA256": digest(parent / "source/internal/gui/pagebridge.js"),
                    "servedInlinedHTMLSHA256": digest(root / "expected-frame.html"),
                })
                asset_hashes = {base + "/index.html": digest(root / "expected-frame.html")}
                for name in ("extensionwindows.js", "pluginpages.js"):
                    asset_hashes["/" + name] = digest(parent / "source/internal/gui/assets" / name)
                save("browser-config.json", {
                    "origin": origin, "page": page, "output": str(root), "secrets": vendor.secrets,
                    "assetSHA256": asset_hashes, "documentPath": base + "/index.html",
                })
                browser_environment = {name: value for name, value in environment.items()
                                       if not name.lower().endswith("_proxy")}
                with (root / "browser.log").open("x") as browser_output:
                    result = subprocess.run([
                        "timeout", "90s", "/usr/bin/node", str(source / "testdata/agent/browser.cjs"),
                        str(root / "browser-config.json"),
                    ], env=browser_environment, cwd=root, stdout=browser_output,
                        stderr=subprocess.STDOUT, timeout=100)
                assert result.returncode == 0, "rendered browser chain failed; preserve browser.log and browser-error.json"
                browser_receipt = json.loads((root / "browser-receipt.json").read_text())
                assert browser_receipt["passed"]
                accounts = [
                    account for path in home.rglob("accounts.json")
                    for account in json.loads(path.read_text())["accounts"]
                ]
                assert len(accounts) == 1
                account = accounts[0]
                assert account["id"] == browser_receipt["account"]["id"] and account["generation"] == 1
                assert account["auth"]["sessionToken"] == vendor.issued["zcode"][0]
                assert vendor.started["zcode"] == len(vendor.issued["zcode"]) == 1
                assert vendor.inferences == {"zcode": 0, "opencode": 0}
                assert observed == {"tickets": 0, "draws": 0, "native": 0, "manualGiftReads": 0, "requests": []}
                assert not vendor.errors, vendor.errors
                save("native-account-proof.json", {
                    "passed": True, "id": account["id"], "generation": account["generation"],
                    "authMatchedSyntheticVendor": True, "vendorStarted": vendor.started,
                    "vendorPolled": vendor.polled, "vendorErrors": vendor.errors,
                    "vendorInferences": vendor.inferences, "executionLedger": observed,
                    "setupCLIOnly": setup, "productionLibrarySHA256": production_library,
                    "fixtureLibrarySHA256": digest(distribution / manifest["entry"]),
                })
            finally:
                process.terminate()
                try:
                    process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)
    rows = [json.loads(line) for line in (root / "ingress.jsonl").read_text().splitlines()]
    counts = Counter(row["kind"] for row in rows)
    assert not set(counts) - {"request", "outside-fixture"}
    sequences = [row["owner"]["proof"]["sequence"] for row in rows if row["kind"] == "request"]
    assert len(sequences) == len(set(sequences))
    ledger = vendor.ingress.ledger
    with ledger.lock:
        ledger.receive()
        save("admission-proof.json", {
            "guardian": ledger.guard, "credentials": ledger.credentials,
            "root": vendor.ingress.root, "usedSequences": sorted(ledger.used),
            "consumedRecords": [json.loads(payload) for payload in ledger.records
                                if json.loads(payload)["sequence"] in ledger.used],
        })
    save("ingress-summary.json", {"counts": dict(counts), "unknown": 0, "uniqueConsumedRequestProofs": sequences,
                                  "foreignOwners": [row["owner"] for row in rows if row["kind"] == "outside-fixture"]})


def main():
    proof = json.loads((previous / "source-proof-after.json").read_text())
    assert digest(host) == proof["hostBinarySHA256"] == "9ddc4e4a076dbcc119e71b5c3b140253e8c419f3278dfadc5d8cdadd59c20adb"
    assert digest(package) == proof["packageSHA256"] == "45d1e73c30379b5911bc1c47c64928828f12988692c66b7611be70e7f681125b"
    assert digest(library) == proof["fixtureLibrarySHA256"]
    assert proof["physicalTree"] == "f7f26b2d5ee5388a089ab07a72f7372ed0068971"
    assert digest(parent / "source.json") == proof["sourceInventorySHA256"]
    assert digest(diagnostic / "final-receipt.json") == "57795c716cc69f34dbf6abf2f56521589369ed08da04d9407cde74cb83b15786"
    assert (source / "testdata/agent/browser.cjs").read_bytes() == (diagnostic / "browser.cjs").read_bytes()
    binding = pasteur / "scripts/magpie-pinned-chromium-channel.cjs"
    assert digest(binding) == "f008c49c95964a76e679f6c361b0c12c527a1c26123849257cdb058af3c8584f"
    for name, expected in proof["moduleSourceFiles"].items():
        assert digest(module / name) == expected, name
    runtimes = json.loads((pasteur / "agent-handoffs/runtime-binaries.json").read_text())
    for entry in runtimes["files"]:
        assert digest(Path(entry["path"])) == entry["sha256"]
    environment = json.loads((previous / "environment.json").read_text())
    home = root / "home"
    home.mkdir(mode=0o700)
    for name, suffix in {
        "HOME": "", "USERPROFILE": "", "XDG_CONFIG_HOME": "config", "XDG_CACHE_HOME": "cache",
        "XDG_DATA_HOME": "data", "XDG_STATE_HOME": "state", "APPDATA": "appdata", "LOCALAPPDATA": "localappdata",
    }.items():
        environment[name] = str(home / suffix)
    environment.update(
        ZCODE_BROWSER_PACKET=str(root), ATTRIBUTION_ROOT=str(root),
        ATTRIBUTION_LIBRARY=str(library), ATTRIBUTION_VENDOR_PORT="34361",
        ATTRIBUTION_CONNECT_LOG=str(root / "connect.jsonl"),
        TMPDIR="/tmp/magpie-gui-pinned-browsers-9sjvuwee/tmp",
        NODE_PATH="/Users/maratkarimov/.cache/magpie-browser/node_modules",
        NODE_OPTIONS="--require=" + str(binding),
        MAGPIE_PINNED_CHROMIUM_LAUNCH_LOGS=str(root / "launch-logs"),
        PLAYWRIGHT_BROWSERS_PATH="/tmp/magpie-gui-pinned-browsers-9sjvuwee/browsers",
        PLAYWRIGHT_SKIP_BROWSER_GC="1", PYTHONDONTWRITEBYTECODE="1",
    )
    (root / "launch-logs").mkdir()
    save("environment.json", environment)
    pins = {
        "hostProof": proof, "runtimes": runtimes,
        "fixtureSHA256": {str(path.relative_to(source)): digest(path)
                         for path in sorted(source.rglob("*")) if path.is_file()},
        "guardSHA256": digest(root / "guard"),
        "diagnosticHelperSHA256": digest(diagnostic / "attribution.py"),
        "previousStrictRedReceiptSHA256": "5be4223d40e9dc3987163634c6c3fc6a02818243a7fbf2b692643034a087b018",
        "causalRedReceiptSHA256": digest(diagnostic / "final-receipt.json"),
    }
    save("pins-before.json", pins)
    command = [str(root / "guard"), str(root / "network.json"), sys.executable,
               str(source / "testdata/agent/browser.py"), "--scenario"]
    started = time.monotonic()
    with (root / "run.log").open("x") as output:
        process = subprocess.Popen(command, env=environment, cwd=root, stdout=output, stderr=subprocess.STDOUT)
        save("command.json", {"pid": process.pid, "argv": command})
        print("browser_scenario_pid", process.pid, flush=True)
        exit_code = process.wait(timeout=180)
    for name, expected in proof["moduleSourceFiles"].items():
        assert digest(module / name) == expected, name
    for entry in runtimes["files"]:
        assert digest(Path(entry["path"])) == entry["sha256"]
    for name, expected in pins["fixtureSHA256"].items():
        assert digest(source / name) == expected, name
    assert digest(host) == proof["hostBinarySHA256"]
    assert digest(parent / "source.json") == proof["sourceInventorySHA256"]
    assert digest(package) == proof["packageSHA256"] and digest(library) == proof["fixtureLibrarySHA256"]
    assert digest(diagnostic / "attribution.py") == pins["diagnosticHelperSHA256"]
    assert digest(root / "guard") == pins["guardSHA256"]
    save("pins-after.json", pins)
    save("result.json", {
        "exit": exit_code, "seconds": round(time.monotonic() - started, 2),
        "physicalTree": proof["physicalTree"], "hostSHA256": digest(host),
        "packageSHA256": digest(package), "sourceAndRuntimePinsUnchanged": True,
        "fullDomainOrGUIRerun": False, "nativeBuilds": 0, "browserCases": 1,
    })
    print((root / "result.json").read_text(), flush=True)
    raise SystemExit(exit_code)


if __name__ == "__main__":
    if sys.argv[1:] == ["--scenario"]:
        scenario()
    else:
        main()
