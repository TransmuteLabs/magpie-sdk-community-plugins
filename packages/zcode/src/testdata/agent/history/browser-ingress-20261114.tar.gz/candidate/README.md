# magpie-sdk-plugin-protocol-zcode

External native Go module for `TransmuteLabs/magpie-sdk-plugin-protocol-zcode`.
The ordinary **0.13.1** package includes provider, controller, owned agent
and UI in one native installation. It uses the shared SDK **1.9**
contract and native ABI **1**, and imports only public SDK packages.
The SDK owns registration and C glue. No community plugin or Bun worker
is required. This is a local checkpoint, not a published SDK release or
an installed activation. Its concurrency defaults and rich quota port
are recorded in [API9-EVIDENCE.md](API9-EVIDENCE.md), with exact source
snapshots and separate parent acceptance gates. Historical 0.12
observability verification uses the owner's
immutable API8 source snapshot `43b7e290d9c3370881780b23ad49222f5d27f44b`,
based on committed host `9e88f10982a1d66c1b402fba27caddda8ac4ac4e`.
The full module retains public API7 Facts and diagnostics, without API8
storage adoption. That historical source snapshot is not a committed SDK release;
acceptance against the final committed host freeze remains separate.
The previous 0.11 package and its API8 compatibility run remain historical
evidence in [API8-COMPAT-EVIDENCE.md](API8-COMPAT-EVIDENCE.md).
The earlier native browser-auth consumer packet is archived unchanged in
[AUTH-WEB-EVIDENCE.md](AUTH-WEB-EVIDENCE.md). Its split-package descriptions
and pending review statements describe that historical checkpoint.
The SDK host can ship independently. This module consumes the parent's
shared API9 contracts and requires no community runtime.
The explicit `--headless` artifact provides the 0.7.2 provider
compatibility surface and runtime floor 1.4.

External Anthropic Messages inference with native GLM reasoning, ToolSearch
round trips, account isolation, streaming backpressure and cancellation.
Declared OffPeak/Highspeed aliases select the native vendor controller;
caller-supplied ticket headers never authorize them. HTTP-200 business
errors are exposed as errors. Partial output or ambiguous dispatch remains
uncertain, without replay.

Paid accounts with an unexpired selected ZCode session also
expose free `-Trial` models from their own gift buckets, including spent
and gift-only names. Trial selection never spends paid quota.
`freeFirst` defaults to true in module configuration; false keeps plain
models on the paid route. A plain free-first request may fall back once
only after a fully read 1005/1113 refusal with no output markers, a
settled principal journal and a fresh paid quota read proving capacity.
Unknown, partial, streamed and transport failures never authorize this
fallback. A confirmed spent model rests for one minute within the instance.
Confirmed inactive paid entitlement exposes gift-only plain names and
Trial aliases. A second, changed or unknown gift balance never turns
gift-only selection into paid authority. Held free-first routes bypass
Start before acceptance; Trial and gift-only remain strict.
Manual Start imports also read the current balance before advertising or
sending a model: excluded, spent or unreadable gift quota cannot authorize
a potentially billed request. A failed discovered paid-plan read stays
closed. A missing Trial bucket can name unclaimed plans from the existing
read-only marketing feed and direct the user to the app's security check;
the hint never claims a plan or creates quota.
Gift replies identify the actual Trial pool in JSON/SSE without changing
text, tool input or signed thinking.

Start requests use the pinned CLI 0.17.1 three-block system/cache shape
and date reminder, preserving caller text and opaque content. Ordinary
paid requests and confirmed paid fallback keep the original envelope.
Session, user-turn query, trace and request attribution reach ordinary
and native-lane inference. The full package reports sparse execution facts:
uncached input, output, cache reads/writes, one-hour cache writes,
reasoning, original served model, response/request IDs, stop and tier.
Explicit zero replaces an earlier count; absent fields remain unknown.
Failed streams retain their last observed snapshot. Facts are observed
before Trial model rewriting and error sanitization.
The pinned Messages source provides no authoritative execution credits,
cost/currency, deferred counts or upstream-provider fact; these stay unknown.
Account quota and balance units never become execution cost or credits.
Code-only diagnostics cover execution, auth, quota, models and named
controller actions through the host's scoped, budgeted callback. They
carry no body, auth, vendor error text or caller-supplied identity; callback
failure never changes execution. This does not add log collection,
consent, retention or remote export.
See [OBSERVABILITY7-EVIDENCE.md](OBSERVABILITY7-EVIDENCE.md).

Start requests use a per-account FIFO with three slots, cancellation and
a two-minute queue timeout. Only HTTP 429 codes 3008/3009/3010 retry,
at one and two seconds. A sustained unused refusal beside other in-flight
requests narrows the cap for five minutes and waits at the queue's head.
Requeues share one two-minute budget, with at most four turns; expiration
cannot admit a new dispatch even if a slot has just become free.
Repeated lone refusals or HTML/Aliyun firewall pages
hold that origin/proxy route for three minutes within the module
instance. These holds are neither durable nor shared across processes.
Ordinary paid requests use the same one/two-second retry waits only for
complete output-free JSON 429 codes 3008/3009/3010, without Start holds.
Native ticket/card inference is never retried.
The bounded community 0.1.63–0.1.66 comparison and its compiled RED,
GREEN, donor oracles and causal removals are recorded in
[DONOR-0166-EVIDENCE.md](DONOR-0166-EVIDENCE.md). The donor checkout remains
unchanged; its runtime is not part of this package.

With a private `dataDir`, the explicit `billing.offers` and
`billing.checkin` module actions and page controls read the pinned client's marketing feed.
They accept an optional exact supported `locale`, default `en-US`.
Check-in claims only declared `claim_zcode_plan` IDs and persists
acknowledgments, refusals, rate holds and unresolved claims.
Code 0 without a plan acknowledges the claim; it does not create a
reported entitlement. No preview endpoint, arbitrary URL/action, captcha
substitute, automatic schedule or native account operation is implemented.
Page check-in requires one current account generation and explicit
confirmation; an uncertain write clears the selection and never repeats.
This bounded port and its remaining donor differences are recorded in
[COMMUNITY-PARITY.md](COMMUNITY-PARITY.md) and
[PARITY-EVIDENCE.md](PARITY-EVIDENCE.md).

An imported snapshot can include a business credential and its bound
project/key location. API 1.3's host-owned refresh transaction then renews
expired paid project tokens and publishes the replacement atomically.
The plugin owns ticket/card journals, billing claims, reset high-water
observations, explicit reconciliation and settlement. Headless init/poll
sign-in, explicit Start reauthorization and dynamic entitlement/config
discovery are implemented. Headless owner tools and standalone offline
history readers/bundle conversion and a real manual SessionMigration adapter
are implemented too. Automatic agent-reader routes, live resume,
proprietary verification mechanisms and live vendor
parity remain separate.
See [CONTRACT-BLOCKERS.md](CONTRACT-BLOCKERS.md) and
[EXTRACTION.md](EXTRACTION.md). Headless-flow verification and exact source
hashes are in [AUTH-EVIDENCE.md](AUTH-EVIDENCE.md); first-slice evidence
remains in [EVIDENCE.md](EVIDENCE.md).
API 1.4 module-scoped proof is in [SDK14-EVIDENCE.md](SDK14-EVIDENCE.md).
Next UI contracts and bounded MCP/history work are specified in
[DOMAIN-CONTRACTS.md](DOMAIN-CONTRACTS.md); they are proposals and remaining
features, not current capability claims.
The headless continuation is verified separately in
[HEADLESS-EVIDENCE.md](HEADLESS-EVIDENCE.md).

Layout:

- `protocol/`: bounded Messages/SSE codecs; no network or SDK runtime.
- `credentials.go`: selected family, product, credential roles and expiry.
- `refresh.go`: one PAT exchange inside API 1.3 host-owned refresh.
- `auth_flow.go`, `auth_complete.go`: private durable polling continuation,
  selected-account reauthorization and paid credential completion.
- `discovery_*.go`, `catalog_rules.go`: scoped project/key selection,
  entitlement checks and ordered dynamic model rules.
- `instance.go`: pure readiness and lazy private storage activation.
- `controller/`: locked, bounded, atomic vendor journals; no host imports.
- `control_client.go`, `lanes.go`: authenticated vendor principal and native
  ticket/card admission derived from the selected declared model.
- `operations.go`, `reconcile.go`: status, settlement and explicit
  reconciliation/abandonment.
- `billing.go`, `checkin.go`, `reset.go`: user-scoped claim/feed check-in
  and account-scoped reset logic.
- `client.go`: fixed vendor destinations, scoped headers and HTTP transport.
- `usage.go`: ordinary five-hour/weekly paid quota with explicit unknowns.
- `gift.go`, `start_guard.go`: strict gift selection, quota isolation,
  bounded safe fallback and per-instance Start admission.
- `tools.go`, `mcp_usage.go`: declared owner-only tools and the separate
  official MCP session/business JWT quota channel.
- `mcp_remote.go`, `mcpwire/`: fixed official image-search transport,
  bounded JSON-RPC/JSON/SSE, session binding and cancellation.
- `history/`: standalone bounded native JSONL/legacy readers and
  source-preserving bundle conversion, including native CLI diagnostic
  JSONL and incomplete tails; no runtime or filesystem access.
- `historydb/`: native Go reader for explicitly supplied, checkpointed
  SQLite snapshots, lossless binary bundles and bounded row inspection.
  The manual `zcode-sqlite-history` adapter supports binary preview,
  host-owned backup/apply and exact restoration. Financial journals can
  be inspected but never converted or imported. Automatic DB/WAL capture
  remains unimplemented in this module.
  Optional native model/turn/tool usage tables retain attempts, exact
  integers, nulls and raw usage without double-counting session messages.
- `sessions.go`: real manual `session.convert` adapter returning an explicit
  host-owned output file plan, with source-overwrite/path guards.
- `usage_barrier_test.go`, `cancel_test.go`: model applicability,
  cross-instance journal barriers and independent cancellation intents.
- `module.go`, `response.go`: public SDK handlers and dispatch boundary.
- `cmd/native/`: historical provider-only native registration.
- `window.go`, `cmd/native-ui/`, `web/`: ordinary full native registration,
  selected-account page, fixed-provider bindings and server-sanitized
  execution summaries.
- `agent.go`: owned SDK 1.5 `zcode-native` profile, source-shaped provider
  configuration plans and explicit host binding revisions.
- `cmd/manifest/`, `build.py`: manifest generation and checked platform ZIP.
- `conformance.py`: two simultaneous native ABI sessions, no vendor traffic.
- `e2e.py`: actual native host refresh/publication/inference, durable
  cancellation and invalidation/read-barrier proof against a loopback
  vendor; only the entry point's destinations are overlaid.
- `auth_e2e.py`: native host CLI init/poll/finish, dynamic models,
  same-account Start reauthorization and inference against a loopback vendor.

SQLite coverage and exact tested source/artifact identities are recorded
in [SQLITE-EVIDENCE.md](SQLITE-EVIDENCE.md). The native driver reuses exact
versions already locked by the SDK host; see
[SQLITE-DEPENDENCIES.md](SQLITE-DEPENDENCIES.md). Runtime parsing never
invokes Python or `sqlite3`. Source provenance and the bounded vendor
comparison are in [SOURCES.md](SOURCES.md) and
[source-lock.json](source-lock.json).

Build and test on **usbox only**, with Go 1.26.8 or the declared compatible
toolchain and a C compiler. Pin `GOPATH`, `GOMODCACHE`, `GOCACHE` before
setting HOME/XDG to a temporary directory. The local `go.mod` replacement
expects an adjacent `../magpie` checkout; release consumers must pin an
available SDK fork revision.
Building the ordinary package requires the SDK 1.9 public types and
already installed `tsc` and `bun` as author tools. Its native manifest
negotiates runtime API 1.9 and includes the ready provider/controller,
AgentWiring profile and static control page.
The ordinary Linux installed fixture uses an incoming process-ownership
boundary; attribution, unchanged strict assertions and causal negatives
are recorded in [AGENT-INGRESS-EVIDENCE.md](AGENT-INGRESS-EVIDENCE.md).
The later packaged Chromium fixture's closed-socket admission repair,
single-use proof controls and preserved browser REDs are recorded in
[BROWSER-INGRESS-EVIDENCE.md](BROWSER-INGRESS-EVIDENCE.md).
The current native lifecycle pin is base `c11acbc2`, physical source tree
`8fe78ab9df13d733d61462eacce19bff523c1e58` and host binary SHA256
`c018c44332ff9238779d1d01340dfd751209c2c694942fd0406e4d6a3c96cc86`.
It reuses the `c8281b6` fixture and existing native libraries; exact package
provenance is in [source-lock.json](source-lock.json), independently of
later shared-host HEAD.

```sh
go test -race ./...
go vet ./...
CGO_ENABLED=1 python3 -I build.py
```

The builder writes `dist/magpie-plugin_<os>_<arch>.zip` and `checksums.txt`,
matching the SDK's GitHub install/update asset contract.
Unpack the ZIP into a new empty directory, then:

```sh
python3 -I conformance.py /path/to/unpacked-distribution
magpie plugin sdk add /path/to/unpacked-distribution
```

Installation is a separate, explicit operation. Tests use synthetic
accounts and local HTTP fixtures and do not modify an installed app.

Bun bundles one classic browser script at build time; the
installed module runs its native Go library and static assets, with no
Bun worker or added server. The packaged public browser adapter comes
from the same SDK checkout used for the native build.
No `--agent` or `--window` build selection or second module is needed.
For historical provider-only compatibility fixtures, `build.py --headless`
writes `dist/compat-sdk14/magpie-plugin_<os>_<arch>.zip`; it is not the
ordinary install artifact. Package-default proof is in
[PACKAGE-EVIDENCE.md](PACKAGE-EVIDENCE.md).
The historical 0.11 donor/observability continuation and its acceptance
are recorded in [COMPLETION-EVIDENCE.md](COMPLETION-EVIDENCE.md).
That ordinary ZIP's subsequent API8 host acceptance, scoped
native rollback and preserved initial compiler failure are recorded in
[API8-COMPAT-EVIDENCE.md](API8-COMPAT-EVIDENCE.md).
The 0.12 API7 package and its separate immutable-source verification
are recorded in [OBSERVABILITY7-EVIDENCE.md](OBSERVABILITY7-EVIDENCE.md).

Credential import uses `auth.finish` with `Input` containing a JSON object:
`site` (`zai`/`bigmodel`), `kind`
(`legacy-key`/`individual`/`team`/`start`), `userId` and `device`.
Legacy uses `key`; paid snapshots use `projectToken`; Start uses
`sessionToken`. Team additionally requires `organization`, `project` and
`product`. The initial paid/Start import requires `expiresAt` in Unix milliseconds more than
30 seconds in the future. Credentials come from `Call.Auth`, never from
an execute request's options or body. Host account ID must match the opaque
ID returned by import.

To enable ongoing paid PAT renewal, import `businessToken`,
`businessExpiresAt` in Unix milliseconds, and `location` containing
`organizationId`, `projectId`, `apiKeyId`. Team location must match its
selected organization/project. Location is part of the account identity.
PAT refresh never borrows another login or discovers/creates a new API key.
It sends one official `access_tokens` request and returns one unary
replacement to the host; no streaming acceptance event is emitted.
Expiry is the minimum of vendor absolute expiry and relative TTL measured
before the exchange. Failed or ambiguous exchanges are never retried.
For Z.ai, `oauthToken` plus `oauthExpiresAt` can renew expired business
material through the recovered `/api/auth/z/login` exchange before issuing
the PAT. Both replacements are returned as one unary result and committed
by the host together. Unknown business lifetime or a failed second stage
remains uncertain. Expired bootstrap, BigModel login renewal and
Start-session renewal require explicit sign-in; no silent refresh endpoint
is invented. The selected-account browser flow preserves account identity.

For a new headless flow, call:

```sh
magpie plugin sdk auth start zcode zcode '{"method":"browser","input":{"site":"zai","kind":"start"}}'
magpie plugin sdk auth finish zcode zcode '{"continuation":{"id":"RETURNED_ID"}}'
```

Open the returned authorization URL yourself and poll `auth finish` at the
returned interval. `kind` supports `individual`, `team`, `start` and `auto`;
`site` supports `zai` and `bigmodel`. Team input accepts explicit
`organization`, `project`, `product` and optional `apiKeyId`. Ambiguous
Team projects are refused; start a new explicit flow with a chosen project.
For renewal, pass the same `--scope '{"account":"ACCOUNT_ID"}'` to both
commands. The CLI resolves the saved generation. A changed generation/user,
missing bound paid key or changed plan cannot replace that account.

The continuation exposes only an opaque random ID. Poll tokens, exchange
material and completion receipts stay in scoped host state. A polling
lease can recover because polling is read-only; an interrupted completion
cannot replay a key/PAT exchange. After uncertain completion start a fresh
explicit sign-in flow and inspect vendor state as needed.

New flow credentials enable fresh entitlement/config discovery. Public
provider configuration receives no account credentials. The selected
plan's ordered rules determine model properties, limits and efforts;
Start discovery keeps declared active buckets visible after exhaustion;
strict Trial dispatch requires confirmed spendable quota. Inference
rechecks eligibility before dispatch. Unknown entitlement, malformed
configuration and unsupported regexp semantics return explicit errors.
Discovery currently runs on each invocation, without an entitlement cache.
`auto` attempts Personal paid selection when that family's material
exists. A session without linked paid material can confirm Start
directly, without touching a paid key/PAT endpoint. Malformed material
or unknown entitlement is refused. For the China login channel, use
`{"site":"bigmodel","kind":"auto","loginProvider":"zai_cn"}` or select
Z.ai China in the page. Login channel is retained for reauthorization;
it does not change the stable family/account identity.

Manual snapshot import remains available and keeps the four archived
default definitions unless `discovery:true` is explicitly supplied.
Those defaults do not prove account entitlement or vendor availability.

Paid quota reads use the selected PAT/key and its family/business endpoint,
including Team organization/project scope. Five-hour and weekly
TOKENS_LIMIT/CREDIT_LIMIT windows are projected separately. Missing metrics
remain unknown, a real zero remains known, and remaining units override a
stale percentage. Ambiguous or failed envelopes fail closed. MCP TIME_LIMIT
windows are marked Aside and cannot become inference allowance. Ordinary
windows explicitly exclude every declared ticket/card alias through
NotModels. Start balances aggregate all active unexpired buckets per exact
model; duplicate model capabilities never duplicate capacity. Remaining
without total/used capacity stays unknown, while a known exhausted model
remains 100%. Malformed capacity fails closed.

API 1.4 usage reads echo the host's canonical revision. Reset/claim first
persist the plugin fence and receive durable acceptance, then invalidate
usage before the vendor POST. A failed invalidation cannot dispatch the
mutation. Reads hold the same principal journal lock across observation
and defer while a reset or shared-user claim remains unsettled. A late
old-revision read cannot clear the host's dirty state; a new-revision read
cannot claim freshness while the plugin journal is unresolved. Credential
rotation is never used as cache invalidation.

## Vendor controller

Configure an absolute private `dataDir` using `plugin sdk config`.
`Start` only validates configuration; candidate installation, validation and
startup never create or migrate that directory. The first authorized
native/control call verifies the session profile and then opens storage.
The module context/disposer owns its lifetime. Do not change `dataDir`
without an explicit stopped-state migration; it is the durable namespace.

Native controls require paid credentials with `sessionToken` and
`sessionExpiresAt`. Every principal comes from this same token's
`/api/v1/oauth/profile` reply, matched to `userId`. Hashing origin/user shares
billing state across Personal, Team and Start slots. Account/task bindings,
draw cooldowns and reset state remain separate. Journal files contain no
credentials, use mode 0600, atomic rename plus fsync, and an OS lock across
processes. Corrupt/unreadable state fails closed.

The four aliases are `GLM-5.3{,-Flash}-{OffPeak,Highspeed}`. Body alias,
selected account, original conversation, raw model and vendor ticket/card
must agree. Pending admission is persisted before vendor I/O. Lost replies
remain fenced across operation IDs, restarts and PAT credential generations.
Highspeed additionally requires the business credential. Reusing a ready
execution for subsequent turns does not take another ticket/card.

Control actions are declared `module-rpc` actions:

- `execution.list`: selected account's stored references.
- `execution.settle`: one fenced Off-Peak settlement; a lost reply is not
  reposted.
- `execution.reconcile`: checks a ticket/card with the vendor. An explicit
  ticket ID is accepted only after the vendor authenticates its original
  task. Acknowledging lost inference output never marks that output known.
- `execution.abandon`: explicit uncertainty acknowledgment; old task stays
  terminal and is never retaken.
- `billing.status`, `billing.claim`: plan baseline, verified policy,
  cross-selection fence and observation after lost replies. Observed
  entitlement does not prove this claim caused it.
- `reset.status`, `reset.use`, `reset.opportunity`, `reset.ack`,
  `reset.resolve`: exact reset windows, durable keys, high-water
  reconciliation, cooldowns and explicit uncertainty acknowledgment.

All writes require a fresh `Scope.Operation` intent ID; retries of that
intent retain its ID. Credentials come only from selected `Frame.Auth`.
`operation.status` returns stored execution outcomes. API 1.4
`operation.cancel` uses a fresh Scope.Operation write intent and the
original operationId or reference as its target. It returns that target,
keeps the original inference journal intact and uses the same durable
Off-Peak settlement fence across callers/processes. The declared
`execution.settle` action remains available. Highspeed cancellation without
an authenticated recovered vendor exchange is explicitly unsupported.

Verification-required claims are refused before a financial POST. Reset
`used:true` alone is insufficient: newer history must confirm acceptance.
An unacknowledged lost reset reply remains unresolved even if history
advances. No scheduler automatically requests gifts, resets or cards.

The archived SQLite journal, live accounts, app state and sessions are not
automatically migrated. Before production activation, existing unresolved
vendor state needs an explicit reviewed import. Fixtures and local module
installation do not prove live entitlements or complete ZCode parity.

## Headless owner tools

Nine real ToolProvider declarations use `Exposure: local-owner`:

- `zcode_account_status`: sanitized saved identity/expiry status, no tokens.
- `zcode_usage`: informational quota observation with no revision acknowledgment.
- `zcode_mcp_usage`: official MCP aggregate, always Aside/informational.
- `zcode_image_search`: fixed official `search_image` execution with `query`.
- `zcode_execution_list`: controller references with ticket/card values removed.
- `zcode_billing_status`, `zcode_reset_status`: read-only vendor state.
- `zcode_history_inspect`, `zcode_history_convert`: explicit supplied bytes only.

For direct local management, use the SDK account scope:

```sh
magpie plugin sdk call zcode tool.call '{"id":"zcode_mcp_usage","arguments":{}}' --scope '{"provider":"zcode","account":"ACCOUNT_ID","operation":"UNIQUE_CALL_ID"}'
```

The CLI resolves the saved current generation and the host supplies
Frame.Auth. Through the existing gateway MCP bridge, `_magpie` is an
optional schema property consumed by the host. A direct module call that
still contains `_magpie`, replacement credentials, headers or arbitrary
scope arguments is rejected.

The official MCP read uses a verified selected ZCode profile, the session
JWT and the paid business/MaaS JWT; Personal/Team target is explicit.
It never substitutes a PAT/API key, refreshes credentials or downgrades to
free service. Missing paid material returns an explicit error.
Reset/claim/settlement remain their separate declared write actions with
existing durable fences.

After a reset's explicit uncertainty resolution, `zcode_usage` may observe
fresh vendor data but still cannot clear host dirty state. The actual
provider.usage protocol must perform the matching-revision acknowledgment.
This is exercised with separate native-host CLI calls.

## Fixed official remote MCP

`zcode_image_search` maps only to the recovered
`POST /api/v1/mcp/server/image_search` endpoint and remote `search_image`.
It initializes protocol `2025-06-18`, sends the initialized notification,
checks bounded advertised tool pages and dispatches one call. It supports
JSON and SSE responses, exact JSON-RPC IDs, stateless servers and issued
session IDs. Changed sessions, other negotiated versions, server-initiated
requests and unsupported query schemas fail explicitly.

```sh
magpie plugin sdk call zcode tool.call '{"id":"zcode_image_search","arguments":{"query":"search terms"}}' --scope '{"provider":"zcode","account":"ACCOUNT_ID","operation":"UNIQUE_CALL_ID"}'
```

The selected session/business JWT snapshot is used throughout; caller
arguments cannot choose URL, tool, headers, protocol or session. Preflight
failure dispatches no tool. The host receives acceptance before one
`tools/call`; a lost response remains uncertain, without replay, fallback
or redirect. Cancellation closes the request and sends one bounded
best-effort notification naming the original JSON-RPC request.

MCP content blocks and `isError` are preserved. SDK 1.4's ToolResult has no
structured-content field, so additional result fields are retained in a
namespaced JSON text block `zcodeMCPResultFields`; this is not native
structured-output parity. Unknown advertised tools are never published.
Remote calls do not acknowledge the ordinary provider quota barrier.
See [REMOTE-MCP-EVIDENCE.md](REMOTE-MCP-EVIDENCE.md) for synthetic/native
proof and protocol/platform limits. No live vendor availability is implied.

## Offline history API

The pure `history` package exports `Read(format, body)` and
`Convert(from, to, body)`. Supported source formats are `zcode-native-jsonl`
and `zcode-legacy-session`. `Document.Summary`, `Records` and `Source` return
owned copies. Native records retain opaque blocks and signatures; legacy
snapshots retain tool details, checkpoints, file changes and body references.
External body/file references are reported and are never fetched.

Conversion to `zcode-history-bundle-v1` stores the original source bytes,
format and checked SHA-256. Restoring that original format preserves exact
bytes, including whitespace and large integers. Corrupt/recursive/unknown
bundle schemas and unsupported cross-agent targets fail explicitly.
The bundle does not authorize a live execution or make missing external
bodies complete.

The registered manual adapter is `zcode-history`. It accepts one
SessionRequest document, explicit source/target formats and
`options: {"outputPath":"relative-target"}`. Native/legacy → bundle and
bundle → its original format are supported. It rejects source overwrite,
unsafe paths, multiple/mixed inputs, unknown options and unsupported
cross-agent conversion. Its result ID is content-derived rather than an
imported task/ticket identity.

`magpie plugin sdk session` previews this file plan under an explicit
`--root` and target `--path`; only `--apply --backup-dir` writes it.
The host owns snapshots, backups and rollback. The adapter performs no IO,
vendor call or live resume and advertises no automatic agent-reader route.
Actual native preview/apply/backup/restore is verified in
[SESSION-EVIDENCE.md](SESSION-EVIDENCE.md).

Bounds are 8 MiB and 16,384 records for standalone sources; tool inputs
additionally limit supplied source to 1 MiB. JSON depth/duplicate-key,
UTF-8 and bundle-integrity checks apply. No source path is opened, no
installed application is inspected by this JSONL/legacy converter. SQLite
uses the separate explicit snapshot adapter described earlier. Automatic
history capture and live resume remain separate work.

## Owned ZCode agent in the native/UI bundle

`python3 build.py` packages provider `zcode`, its TypeScript page and
AgentWiring profile `zcode-native` as one native installation. Connect it
through the host's ordinary Agents controls, then select a published model.
`magpie zcode-native env` shows the checked launch environment and
`magpie zcode-native run ...` starts the ZCode executable on PATH with literal
arguments. The actual executable is supplied separately by the user.

The adapter plans changes to `.zcode/v2/provider_config.json`, schema 1.
Only the host gateway URL and agent key enter that file. Host snapshots,
binding revisions, backups and file plans own all writes. Existing API
format, provider names, manual model rules and compatible selected reasoning
options survive sync; disconnect restores original owned rules and selection
while retaining foreign edits. A new file is removed when restoration leaves
no user changes. Stale bindings, file drift, changed module configuration
and a disabled module refuse launch.

API9 agent options accept the public typed `decisionModels` list and validate
it independently of chat models. Unknown option fields and malformed
decision facts are refused before a file plan. Decision-only models never
enter the ZCode chat catalog or become selectable chat models; the legacy
absent list and an explicit empty API9 list remain accepted.

The profile inherits ZCode's default `.zcode/AGENTS.md`, skills and
`.zcode/cli/config.json` MCP placement. Custom data roots are outside this
adapter. On usbox a synthetic executable exercises ordinary launch, native
model aliases and Library; no actual ZCode client startup or browser rendering
is claimed. See [AGENT-EVIDENCE.md](AGENT-EVIDENCE.md) and
[ONE-BUNDLE-AUDIT.md](ONE-BUNDLE-AUDIT.md).

## SDK 1.5 control-page variant

The ordinary full package includes the TS/HTML/CSS page. It discovers saved
account summaries through the host, requires explicit selection and keeps
the exact string generation. The host's fixed binding owns provider
`zcode`; no client provider, free-form scope or credentials are accepted.
The five bindings expose execution summaries, plan/reset status and
explicit reset/claim. The UI-only `execution.summary` action strips
ticket/card values on the native side without changing headless
`execution.list`.

The page uses the existing sandbox/bridge and an in-page HTML dialog;
there is no sandbox-blocked browser confirm, form submission, ES-module
network load or direct backend HTTP request. Account selection is locked
while confirming or executing a write. A changed generation requires
reselection, late reads cannot overwrite a write, and uncertain actions
are never automatically repeated.

Configure the private `dataDir` separately before using native controls.
The optional page now exposes new sign-in, selected-account reauthorization
and explicit poll/cancel through the host-owned broker. Its fixed
provider/method binding never exposes credentials or continuations.
Completion requires fresh explicit selection, and lost replies never
restart an exchange. No credential editor, logout or silent Start renewal
is invented. `prototype/ui-sdk15` now
re-exports the promoted state layer for its retained regressions.
See [UI-EVIDENCE.md](UI-EVIDENCE.md) for exact source/artifact hashes,
actual native web-route proof, isolated network verification and the
distinction between DOM tests and browser rendering.
The historical 0.8.0 checkpoint fixes, exact source/artifact identities and production
IIFE/native broker proof are in [READINESS-EVIDENCE.md](READINESS-EVIDENCE.md).
