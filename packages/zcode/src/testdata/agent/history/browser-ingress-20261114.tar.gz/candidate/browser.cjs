const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { chromium } = require("playwright");

const config = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const sha = (bytes) => crypto.createHash("sha256").update(bytes).digest("hex");
const output = (name, value) => fs.writeFileSync(path.join(config.output, name), JSON.stringify(value, null, 2) + "\n");

async function main() {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ viewport: { width: 1280, height: 1000 }, locale: "en-US" });
  const page = await context.newPage();
  const replies = [];
  const assets = [];
  const errors = [];
  const pending = [];
  let frame;
  await context.addInitScript(() => {
    window.__zcodeObservedMessages = [];
    addEventListener("message", (event) => {
      if (event.data?.magpie === 1) window.__zcodeObservedMessages.push({
        data: event.data,
        sourceIsParent: event.source === parent,
        sourceIsChild: [...document.querySelectorAll("iframe")].some((element) => element.contentWindow === event.source),
      });
    });
  });
  page.on("pageerror", (error) => errors.push({ message: error.message, stack: error.stack }));
  page.on("response", (response) => {
    const url = new URL(response.url());
    if (url.origin !== config.origin) return;
    const expected = config.assetSHA256[url.pathname];
    if (expected) pending.push((async () => {
      const bytes = await response.body();
      if (url.pathname === config.documentPath) fs.writeFileSync(path.join(config.output, "loaded-frame.html"), bytes);
      assets.push({ path: url.pathname, sha256: sha(bytes), expected, status: response.status(), csp: response.headers()["content-security-policy"] ?? "" });
    })());
    if (/^\/api\/plugin-pages\/(auth|accounts|call)$/.test(url.pathname)) pending.push((async () => {
      replies.push({
        path: url.pathname, status: response.status(),
        request: response.request().postDataJSON(),
        result: await response.json(),
      });
    })());
  });
  try {
    await page.goto(config.origin + "/?k=synthetic-zcode-render-key", { waitUntil: "domcontentloaded" });
    const tab = page.locator('#nav button[data-plugin-page][data-view="' + config.page.key + '"]');
    await tab.waitFor({ state: "visible", timeout: 30000 });
    await tab.click();
    const iframe = page.locator('iframe.plugin-frame[src*="' + config.page.ref + '"]');
    await iframe.waitFor({ state: "visible" });
    assert.equal(await iframe.getAttribute("sandbox"), "allow-scripts");
    frame = await (await iframe.elementHandle()).contentFrame();
    assert.ok(frame && frame !== page.mainFrame());
    await frame.locator("#signin").waitFor({ state: "visible" });
    await frame.waitForFunction(() => !document.querySelector("#account").disabled);
    assert.equal(await frame.locator("h1").innerText(), "Управление счётом");
    assert.equal(await frame.locator("#account option").count(), 1);
    const initialDOM = await frame.locator("main").innerText();
    const sandbox = await frame.evaluate(() => {
      let parentReadable = false, storageReadable = false;
      try { parentReadable = !!parent.document; } catch {}
      try { storageReadable = typeof localStorage.length === "number"; } catch {}
      return { parentReadable, storageReadable, theme: document.documentElement.dataset.theme };
    });
    assert.equal(sandbox.parentReadable, false);
    assert.equal(sandbox.storageReadable, false);
    assert.ok(["dark", "light"].includes(sandbox.theme));
    await frame.locator("#auth-site").selectOption("zai");
    await frame.locator("#auth-kind").selectOption("start");
    const authResponse = () => page.waitForResponse((response) =>
      new URL(response.url()).pathname === "/api/plugin-pages/auth", { timeout: 15000 });
    let received = authResponse();
    await frame.locator("#signin").click();
    let flow = await (await received).json();
    assert.ok(["waiting", "pending"].includes(flow.state));
    assert.ok(flow.flow);
    for (let attempt = 0; attempt < 6 && flow.state !== "complete"; attempt++) {
      await page.waitForTimeout(Math.max(flow.retryAfterMs ?? 1000, 1000) + 100);
      await frame.waitForFunction(() => !document.querySelector("#auth-poll").disabled);
      received = authResponse();
      await frame.locator("#auth-poll").click();
      flow = await (await received).json();
    }
    assert.equal(flow.state, "complete");
    assert.equal(flow.account.generation, "1");
    assert.deepEqual(Object.keys(flow.account).sort(), ["expiresAt", "generation", "id"]);
    await frame.waitForFunction(() => document.querySelector("#auth-status").textContent.includes("Вход завершён. Выберите"));
    await frame.waitForFunction(() => document.querySelectorAll("#account option").length === 2);
    assert.equal(await frame.locator("#account").inputValue(), "");
    await frame.locator("#account").selectOption(flow.account.id);
    const actionResponse = page.waitForResponse((response) =>
      new URL(response.url()).pathname === "/api/plugin-pages/call", { timeout: 15000 });
    await frame.locator("#executions").click();
    assert.deepEqual(await (await actionResponse).json(), []);
    await frame.waitForFunction(() => document.querySelector("#status").textContent === "Исполнения загружены.");
    assert.deepEqual(JSON.parse(await frame.locator("#output").innerText()), []);
    await page.screenshot({ path: path.join(config.output, "parent.png"), fullPage: true });
    await iframe.screenshot({ path: path.join(config.output, "iframe.png") });
    const messages = {
      parent: await page.evaluate(() => window.__zcodeObservedMessages),
      frame: await frame.evaluate(() => window.__zcodeObservedMessages),
    };
    await Promise.all(pending);
    const auth = replies.filter((reply) => reply.path.endsWith("/auth"));
    const reads = replies.filter((reply) => reply.path.endsWith("/call"));
    assert.equal(auth.filter((reply) => reply.request.operation === "start").length, 1);
    assert.equal(reads.length, 1);
    assert.equal(reads[0].request.binding, "page.execution-list");
    assert.deepEqual(reads[0].request.account, { id: flow.account.id, expectedGeneration: "1" });
    assert.ok(messages.parent.some((message) => message.sourceIsChild && message.data.method === "auth.start"));
    assert.ok(messages.parent.some((message) => message.sourceIsChild && message.data.method === "backend.call"));
    assert.ok(messages.frame.some((message) => message.sourceIsParent && message.data.result?.state === "complete"));
    for (const assetPath of Object.keys(config.assetSHA256)) {
      const matches = assets.filter((asset) => asset.path === assetPath);
      assert.ok(matches.length, "actual browser did not load pinned asset " + assetPath);
      assert.ok(matches.every((asset) => asset.sha256 === asset.expected && asset.status === 200), assetPath);
    }
    const documentAsset = assets.find((asset) => asset.path === config.documentPath);
    assert.ok(documentAsset.csp.includes("sandbox allow-scripts"));
    assert.ok(documentAsset.csp.includes("connect-src 'none'"));
    const finalDOM = await frame.locator("main").innerText();
    const publicMaterial = JSON.stringify({ messages, replies, initialDOM, finalDOM });
    for (const secret of config.secrets) assert.equal(publicMaterial.includes(secret), false, "private fixture value reached browser");
    assert.equal(errors.length, 0, "real browser raised JavaScript errors");
    output("browser-receipt.json", {
      passed: true, browserVersion: browser.version(),
      playwrightVersion: require("playwright/package.json").version,
      ordinaryGUIParent: true, renderedPackagedIframe: true,
      browserRoutingMocks: false, directUIOrBackendCalls: false,
      account: flow.account, nativeAuthStarts: 1, selectedAccountReads: 1,
      sandbox, initialDOM, finalDOM, assets, replies, messages, errors,
      actualClientPresent: false, syntheticEndpointsOnly: true,
    });
    console.log("rendered_native_auth_and_selected_read GREEN");
  } finally {
    await Promise.allSettled(pending);
    output("browser-observations.json", { assets, replies, errors });
    if (frame) {
      try { output("last-dom.json", { parent: await page.locator("body").innerText(), frame: await frame.locator("body").innerText() }); } catch {}
    }
    await context.close();
    await browser.close();
  }
}

main().catch((error) => {
  output("browser-error.json", { name: error.name, message: error.message, stack: error.stack });
  console.error(error);
  process.exitCode = 1;
});
