import importlib.util
import copy
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request


spec = importlib.util.spec_from_file_location("zcode_admission_ingress", Path(__file__).with_name("ingress.py"))
ingress = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ingress)
source = Path(__file__).resolve().parents[2]


class AdmissionTests(unittest.TestCase):
    def closed_child(self, mutate=None, replay=False):
        with tempfile.TemporaryDirectory() as root, ingress.owned_vendor(source, root) as vendor:
            release = threading.Event()
            finished = threading.Event()
            handled = threading.Event()
            verify = vendor.server.verify_request
            base = vendor.server.RequestHandlerClass
            admissions = []

            class Handler(base):
                def handle_one_request(self):
                    try:
                        super().handle_one_request()
                    except (BrokenPipeError, ConnectionResetError):
                        pass

                def finish(self):
                    try:
                        super().finish()
                    finally:
                        handled.set()

            def after_client_exit(connection, address):
                original_records = None
                if not release.wait(5):
                    raise RuntimeError("closed child barrier expired")
                try:
                    if mutate:
                        ledger = vendor.ingress.ledger
                        with ledger.lock:
                            ledger.receive()
                            original_records = ledger.records[:]
                            matches = [
                                offset for offset, payload in enumerate(ledger.records)
                                if json.loads(payload)["local"] == list(address)
                            ]
                            self.assertEqual(len(matches), 1)
                            mutate(ledger, matches[0])
                    admitted = verify(connection, address)
                    admissions.append(admitted)
                    if replay:
                        admissions.append(verify(connection, address))
                    return admitted
                finally:
                    if original_records is not None:
                        ledger.records[:] = original_records
                    finished.set()

            vendor.server.verify_request = after_client_exit
            vendor.server.RequestHandlerClass = Handler
            child = subprocess.Popen([
                sys.executable, "-I", "-c",
                "import socket,sys\n"
                "with socket.create_connection(('127.0.0.1',int(sys.argv[1])),timeout=3) as client:\n"
                " client.sendall(b'GET /updates HTTP/1.0\\r\\nHost: fixture\\r\\n\\r\\n')\n"
                " client.shutdown(socket.SHUT_WR)\n",
                str(vendor.server.server_port),
            ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            _, errors = child.communicate(timeout=10)
            self.assertEqual(child.returncode, 0, errors)
            self.assertFalse(Path("/proc", str(child.pid)).exists())
            release.set()
            self.assertTrue(finished.wait(5))
            vendor.server.shutdown()
            if admissions[0]:
                self.assertTrue(handled.wait(5))
            records = [json.loads(line) for line in (Path(root) / "ingress.jsonl").read_text().splitlines()]
            requests = [record for record in records if record["kind"] == "request"]
            return vendor.errors, requests, admissions

    def test_closed_child_is_admitted_before_strict_http(self):
        errors, requests, admissions = self.closed_child()
        self.assertEqual(errors, [])
        self.assertEqual(admissions, [True])
        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["method"], "GET")
        self.assertEqual(requests[0]["uri"], "/updates")
        self.assertEqual(requests[0]["owner"]["proof"]["admission"], "closed-socket")

    def test_closed_proof_is_consumed_once(self):
        errors, requests, admissions = self.closed_child(replay=True)
        self.assertEqual(admissions, [True, False])
        self.assertEqual(len(errors), 1)
        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["owner"]["proof"]["admission"], "closed-socket")

    def test_live_proof_cannot_be_reused_by_fallback(self):
        with tempfile.TemporaryDirectory() as root, ingress.owned_vendor(source, root) as vendor:
            verify = vendor.server.verify_request
            admissions = []

            def twice(connection, address):
                admitted = verify(connection, address)
                admissions.append(admitted)
                if admitted:
                    vendor.ingress.live_owner = lambda connection: unavailable()
                    admissions.append(verify(connection, address))
                return admitted

            def unavailable():
                raise ingress.OwnerUnavailable("synthetic close after live admission")

            vendor.server.verify_request = twice
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with self.assertRaises(urllib.error.HTTPError) as caught:
                opener.open(vendor.origin + "/updates", timeout=5)
            caught.exception.close()
            vendor.server.shutdown()
            self.assertEqual(admissions, [True, False])
            self.assertEqual(len(vendor.errors), 1)
            records = [json.loads(line) for line in (Path(root) / "ingress.jsonl").read_text().splitlines()]
            requests = [record for record in records if record["kind"] == "request"]
            self.assertEqual(len(requests), 1, records)
            self.assertEqual(requests[0]["owner"]["proof"]["admission"], "live")

    def test_actual_admission_rejects_missing_conflicting_stale_foreign_and_ambiguous(self):
        def changed(field, value):
            def mutate(ledger, offset):
                record = json.loads(ledger.records[offset])
                record[field] = value(record) if callable(value) else value
                ledger.records[offset] = json.dumps(record).encode()
            return mutate

        cases = {
            "missing": lambda ledger, offset: ledger.records.pop(offset),
            "ambiguous": lambda ledger, offset: ledger.records.append(ledger.records[offset]),
            "stale": changed("connectStartMonotonicNs", lambda record: time.monotonic_ns() - 6_000_000_000),
            "caller-startTicks": changed("startTicks", lambda record: record["startTicks"] + 1),
            "foreign-lineage": changed("lineage", lambda record: record["lineage"][:1]),
            "failed-identity": changed("identityResult", -1),
            "missing-inode": changed("inode", 0),
            "failed-connect": changed("errno", 111),
        }
        for label, mutate in cases.items():
            with self.subTest(label=label):
                errors, requests, admissions = self.closed_child(mutate)
                self.assertEqual(admissions, [False])
                self.assertEqual(len(errors), 1)
                self.assertEqual(requests, [])

    def test_actual_admission_rejects_a_conflicting_known_inode(self):
        original = ingress.OwnedIngress.socket_inodes

        def conflict(audit, connection):
            return original(audit, connection) | {"999999999999"}

        ingress.OwnedIngress.socket_inodes = conflict
        try:
            errors, requests, admissions = self.closed_child()
            self.assertEqual(admissions, [False])
            self.assertEqual(len(errors), 1)
            self.assertEqual(requests, [])
        finally:
            ingress.OwnedIngress.socket_inodes = original

    def test_channel_is_not_a_file_or_a_self_authored_socket(self):
        with tempfile.TemporaryFile() as file:
            with self.assertRaises(OSError):
                ingress.ledger_module.ConnectLedger(os.dup(file.fileno()))
        receiver, sender = socket.socketpair(socket.AF_UNIX, socket.SOCK_SEQPACKET)
        with receiver, sender:
            receiver.setsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED, 1)
            with self.assertRaisesRegex(RuntimeError, "guardian"):
                ingress.ledger_module.ConnectLedger(os.dup(receiver.fileno()))
        ledger = ingress.ledger_module.configured_ledger()
        self.assertFalse(ledger.channel.get_inheritable())
        with self.assertRaises(BrokenPipeError):
            ledger.channel.send(b"cannot author guardian proof")
        with self.assertRaises(PermissionError):
            list(Path("/proc", str(ledger.guard["pid"]), "fd").iterdir())
        result = subprocess.run([
            sys.executable, "-I", "-c",
            "import os\n"
            "try: os.fstat(198)\n"
            "except OSError: pass\n"
            "else: raise AssertionError('proof channel leaked through exec')\n",
        ], capture_output=True, timeout=5)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_existing_correlation_negatives_remain_admission_validation_failures(self):
        root = {"pid": 100, "ppid": 90, "startTicks": 1000}
        peer, local = ("127.0.0.1", 38498), ("127.0.0.1", 34361)
        record = {
            "local": list(peer), "remote": list(local),
            "connectStartMonotonicNs": 200, "monotonicNs": 210,
            "pid": 101, "tid": 102, "ppid": 100, "startTicks": 1100, "tidStartTicks": 1101,
            "identityResult": 0, "stable": True, "inode": 10, "result": 0, "errno": 0,
            "lineage": [{"pid": 101, "ppid": 100, "startTicks": 1100}, root],
        }

        def validate(value, remote=peer, inodes=None):
            ingress.ledger_module.validate(value, root, remote, local, 100, 300, 400,
                                            {"10"} if inodes is None else inodes)

        validate(record)
        changes = {
            "source-port": lambda value: value["local"].__setitem__(1, 38499),
            "target-port": lambda value: value["remote"].__setitem__(1, 34362),
            "future-time": lambda value: value.__setitem__("monotonicNs", 401),
            "missing-root": lambda value: value.__setitem__("lineage", value["lineage"][:1]),
            "root-PID-reuse": lambda value: value["lineage"][1].__setitem__("startTicks", 1001),
            "caller-PID-reuse": lambda value: value.__setitem__("startTicks", 1101),
            "identity-capture": lambda value: value.__setitem__("identityResult", -1),
            "missing-inode": lambda value: value.__setitem__("inode", 0),
            "unstable-identity": lambda value: value.__setitem__("stable", False),
            "broken-ancestry": lambda value: value["lineage"][0].__setitem__("ppid", 99),
        }
        for label, mutate in changes.items():
            with self.subTest(label=label):
                changed = copy.deepcopy(record)
                mutate(changed)
                with self.assertRaises(RuntimeError):
                    validate(changed)
        with self.assertRaises(RuntimeError):
            validate(record, inodes={"11"})
        for port in (43908, 43914, 43988):
            with self.subTest(historicalUnknown=port), self.assertRaises(RuntimeError):
                validate(record, remote=("127.0.0.1", port))
        with self.assertRaisesRegex(RuntimeError, "stale"):
            ingress.ledger_module.validate(record, root, peer, local, 100, 6_000_000_300,
                                            6_000_000_400, {"10"})


if __name__ == "__main__":
    unittest.main()
