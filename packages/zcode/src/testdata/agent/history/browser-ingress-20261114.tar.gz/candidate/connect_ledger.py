import atexit
import errno
import json
import os
import select
import socket
import struct
import threading
import time
from pathlib import Path


MAX_AGE_NS = 5_000_000_000
MAX_RECORDS = 4096
_ledger = None


def identity(pid):
    fields = (Path("/proc") / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()
    return {"pid": pid, "ppid": int(fields[1]), "startTicks": int(fields[19])}


def validate(record, root, peer, local, started_ns, accepted_ns, now_ns, inodes):
    if record["local"] != list(peer) or record["remote"] != list(local):
        raise RuntimeError("connect tuple mismatch")
    if not (started_ns <= record["connectStartMonotonicNs"] <= accepted_ns
            <= now_ns and record["connectStartMonotonicNs"] <= record["monotonicNs"] <= now_ns):
        raise RuntimeError("connect time mismatch")
    if accepted_ns - record["connectStartMonotonicNs"] > MAX_AGE_NS:
        raise RuntimeError("stale connect proof")
    if (record["identityResult"] != 0 or record["stable"] is not True or record["inode"] <= 0
            or record["pid"] <= 1 or record["tid"] <= 1 or record["startTicks"] <= 0
            or record["tidStartTicks"] <= 0
            or (record["result"], record["errno"]) not in ((0, 0), (-1, errno.EINPROGRESS))):
        raise RuntimeError("invalid connect identity or result")
    lineage = record["lineage"]
    if not lineage or len(lineage) > 64:
        raise RuntimeError("missing connect lineage")
    if any(record[key] != lineage[0][key] for key in ("pid", "ppid", "startTicks")):
        raise RuntimeError("connect caller identity mismatch")
    seen = set()
    for offset, process in enumerate(lineage):
        if process["pid"] in seen or process["startTicks"] <= 0:
            raise RuntimeError("ambiguous connect lineage")
        seen.add(process["pid"])
        if offset and lineage[offset - 1]["ppid"] != process["pid"]:
            raise RuntimeError("broken connect lineage")
        if all(process[key] == root[key] for key in ("pid", "ppid", "startTicks")):
            break
    else:
        raise RuntimeError("foreign connect lineage")
    if inodes and inodes != {str(record["inode"])}:
        raise RuntimeError("connect inode mismatch")


class ConnectLedger:
    def __init__(self, descriptor):
        self.channel = socket.socket(fileno=descriptor)
        self.channel.set_inheritable(False)
        try:
            if (self.channel.family != socket.AF_UNIX
                    or self.channel.getsockopt(socket.SOL_SOCKET, socket.SO_TYPE) != socket.SOCK_SEQPACKET
                    or self.channel.getsockopt(socket.SOL_SOCKET, socket.SO_PASSCRED) != 1):
                raise RuntimeError("connect proof requires credentialled seqpacket channel")
            credentials = self.channel.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12)
            self.credentials = struct.unpack("3i", credentials)
            self.guard = identity(self.credentials[0])
            self.root = identity(os.getpid())
            if (self.credentials[1:] != (os.getuid(), os.getgid())
                    or self.root["ppid"] != self.guard["pid"]):
                raise RuntimeError("connect proof writer is not the fixture guardian")
        except BaseException:
            self.channel.close()
            raise
        self.channel.setblocking(False)
        self.records = []
        self.used = set()
        self.lock = threading.Lock()
        self.failure = None
        atexit.register(self.channel.close)

    def receive(self):
        if self.failure:
            raise RuntimeError(self.failure)
        if identity(self.guard["pid"]) != self.guard:
            raise RuntimeError("connect proof writer identity changed")
        while select.select([self.channel], [], [], 0)[0]:
            payload, control, flags, _ = self.channel.recvmsg(65536, socket.CMSG_SPACE(12))
            credentials = [
                struct.unpack("3i", value) for level, kind, value in control
                if level == socket.SOL_SOCKET and kind == socket.SCM_CREDENTIALS and len(value) == 12
            ]
            if (not payload or flags & (socket.MSG_TRUNC | socket.MSG_CTRUNC)
                    or credentials != [self.credentials] or len(self.records) >= MAX_RECORDS):
                self.failure = "connect proof channel closed, unauthenticated or over budget"
                raise RuntimeError(self.failure)
            record = json.loads(payload)
            if record["sequence"] != len(self.records) + 1:
                self.failure = "connect proof sequence mismatch"
                raise RuntimeError(self.failure)
            self.records.append(bytes(payload))

    def consume(self, root, peer, local, started_ns, accepted_ns, inodes, live):
        with self.lock:
            self.receive()
            records = [record for payload in self.records
                       if (record := json.loads(payload))["local"] == list(peer)
                       and record["remote"] == list(local)]
            if len(records) != 1:
                raise RuntimeError("connect proof is missing or ambiguous")
            record = records[0]
            if record["sequence"] in self.used:
                raise RuntimeError("connect proof already consumed")
            validate(record, root, peer, local, started_ns, accepted_ns, time.monotonic_ns(), inodes)
            if live and any(
                process["pid"] != record["pid"] or process["startTicks"] != record["startTicks"]
                for process in live["processes"]
            ):
                raise RuntimeError("live owner conflicts with connect proof")
            self.used.add(record["sequence"])
            process = {key: record[key] for key in ("pid", "ppid", "startTicks", "tid", "fd", "inode")}
            process.update(executable=record["lineage"][0]["executable"],
                           lineage=record["lineage"], owned=True)
            return {"owned": True, "processes": [process], "proof": {
                "sequence": record["sequence"], "source": "guardian-credentials",
                "guard": self.guard, "connectMonotonicNs": record["monotonicNs"],
                "admission": "live" if live else "closed-socket",
            }}


def configured_ledger():
    global _ledger
    descriptor = os.environ.pop("ZCODE_FIXTURE_CONNECT_FD", None)
    if descriptor is not None:
        if _ledger is not None:
            raise RuntimeError("connect proof channel configured twice")
        _ledger = ConnectLedger(int(descriptor))
    return _ledger
