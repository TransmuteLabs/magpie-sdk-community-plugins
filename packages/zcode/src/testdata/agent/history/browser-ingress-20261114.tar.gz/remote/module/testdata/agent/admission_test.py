import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest


spec = importlib.util.spec_from_file_location("zcode_admission_ingress", Path(__file__).with_name("ingress.py"))
ingress = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ingress)
source = Path(__file__).resolve().parents[2]


class AdmissionTests(unittest.TestCase):
    def test_closed_child_is_admitted_before_strict_http(self):
        with tempfile.TemporaryDirectory() as root, ingress.owned_vendor(source, root) as vendor:
            release = threading.Event()
            finished = threading.Event()
            handled = threading.Event()
            verify = vendor.server.verify_request
            base = vendor.server.RequestHandlerClass

            class Handler(base):
                def finish(self):
                    try:
                        super().finish()
                    finally:
                        handled.set()

            def after_client_exit(connection, address):
                if not release.wait(5):
                    raise RuntimeError("closed child barrier expired")
                try:
                    return verify(connection, address)
                finally:
                    finished.set()

            vendor.server.verify_request = after_client_exit
            vendor.server.RequestHandlerClass = Handler
            child = subprocess.Popen([
                sys.executable, "-I", "-c",
                "import socket,sys\n"
                "with socket.create_connection(('127.0.0.1',int(sys.argv[1])),timeout=3) as client:\n"
                " client.sendall(b'GET /updates HTTP/1.0\\r\\nHost: fixture\\r\\n\\r\\n')\n"
                " client.shutdown(socket.SHUT_WR)\n",
                str(vendor.server.server_port),
            ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            _, errors = child.communicate(timeout=10)
            self.assertEqual(child.returncode, 0, errors)
            self.assertFalse(Path("/proc", str(child.pid)).exists())
            release.set()
            self.assertTrue(finished.wait(5))
            vendor.server.shutdown()
            self.assertEqual(vendor.errors, [])
            self.assertTrue(handled.wait(5))
            records = [json.loads(line) for line in (Path(root) / "ingress.jsonl").read_text().splitlines()]
            requests = [record for record in records if record["kind"] == "request"]
            self.assertEqual(len(requests), 1, records)
            self.assertEqual(requests[0]["owner"]["proof"]["admission"], "closed-socket")


if __name__ == "__main__":
    unittest.main()
