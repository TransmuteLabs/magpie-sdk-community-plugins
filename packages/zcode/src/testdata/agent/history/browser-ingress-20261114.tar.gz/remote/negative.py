import importlib.util
import os
from pathlib import Path
import sys
import unittest


root = Path("/tmp/magpie-zcode-ingress-admission-f7-rgsG8ph9")
source = root / "source-final"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


tests = load("zcode_admission_negative", source / "testdata/agent/admission_test.py")
if sys.argv[1:] == ["old-owner"]:
    tests.ingress = load("zcode_old_owner", root / "module/testdata/agent/ingress.py")
    names = ["test_closed_child_is_admitted_before_strict_http"]
elif sys.argv[1:] == ["reuse"]:
    ledger = tests.ingress.ledger_module
    text = (source / "testdata/agent/connect_ledger.py").read_text()
    statement = '            self.used.add(record["sequence"])\n'
    assert text.count(statement) == 1
    text = text.replace(statement, "")
    exec(compile(text, str(source / "testdata/agent/connect_ledger.py") + ":without-consumption", "exec"),
         vars(ledger))
    names = ["test_closed_proof_is_consumed_once", "test_live_proof_cannot_be_reused_by_fallback"]
else:
    raise SystemExit("expected old-owner or reuse")
suite = unittest.TestSuite(tests.AdmissionTests(name) for name in names)
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
