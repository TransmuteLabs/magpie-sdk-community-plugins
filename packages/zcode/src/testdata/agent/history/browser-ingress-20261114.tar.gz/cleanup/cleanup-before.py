import os
from pathlib import Path
import subprocess


def identity(pid):
    fields = Path("/proc", str(pid), "stat").read_text().rsplit(")", 1)[1].split()
    return {"pid": pid, "startTicks": int(fields[19])}


def run_owned(command, *, timeout, grace, **options):
    process = subprocess.Popen(command, start_new_session=True, **options)
    owner = identity(process.pid)
    try:
        child_exit = process.wait(timeout=timeout)
        timed_out = False
    except subprocess.TimeoutExpired:
        child_exit = None
        timed_out = True
    return {"exit": 124 if timed_out else child_exit, "childExit": child_exit,
            "timedOut": timed_out, "ownedGroupStopped": False, "owner": owner}
