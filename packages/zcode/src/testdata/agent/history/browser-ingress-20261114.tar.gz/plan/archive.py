import difflib
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile


repo = Path(__file__).resolve().parents[2]
packet = Path(__file__).resolve().parent
remote = packet / "remote"
cleanup = packet / "cleanup-closure"
candidate = packet / "preserved-candidate"
history = repo / "testdata/agent/history"
history.mkdir(exist_ok=True)
archive = history / "browser-ingress-20261114.tar.gz"
manifest = history / "browser-ingress-20261114.json"
members = {}


def digest(body):
    return hashlib.sha256(body).hexdigest()


def read(path):
    return json.loads(path.read_text())


def add(name, path):
    assert name not in members
    members[name] = path.read_bytes()


baseline = "8c53c6b5a2f7e1ae00b66e54b4d933cc9e31b40510ac9d0064ac3a39680ecf12"
assert digest((repo / "testdata/agent/ingress.py").read_bytes()) == baseline
assert subprocess.check_output(["git", "show", "HEAD:testdata/agent/ingress.py"], cwd=repo) == (
    repo / "testdata/agent/ingress.py").read_bytes()
assert digest((candidate / "REVIEW.txt").read_bytes()) == (
    "7243d5b2cb6d35cda1c45734cd40ddf31cd4bb8511a36f6fa6c1cec8ca6c969b")
assert read(remote / "browser/result.json")["exit"] == 1
assert read(remote / "browser/result.json")["seconds"] == 17.02
assert (remote / "browser/pins-before.json").read_bytes() == (
    remote / "browser/pins-after.json").read_bytes()

for inventory, source, patch_name in (
    ("source-hashes.json", "source-final", "fixture.patch"),
    ("source-browser-hashes.json", "source-browser", "fixture-browser.patch"),
):
    for name, expected in read(remote / inventory).items():
        path = remote / name if name == patch_name else remote / source / name
        assert digest(path.read_bytes()) == expected, name

for name in ("cleanup-final", "active-boundary-final"):
    assert read(cleanup / (name + "-result.json"))["exit"] == 0
assert read(cleanup / "old-cleanup-final-result.json")["exit"] == 1
for name in ("owned_run.py", "cleanup_test.py"):
    assert (repo / "testdata/agent" / name).read_bytes() == (cleanup / name).read_bytes()

private = {"browser/environment.json", "browser/browser-config.json"}
compiled = {"guard", "guard-final", "guard-v1", "browser/guard"}
for path in sorted(remote.rglob("*")):
    if not path.is_file():
        continue
    name = path.relative_to(remote).as_posix()
    if name in private | compiled:
        continue
    assert path.suffix in {".py", ".c", ".cjs", ".log", ".json", ".jsonl", ".patch", ".html"}, name
    add("remote/" + name, path)
for path in sorted(candidate.iterdir()):
    add("candidate/" + path.name, path)
for path in sorted(cleanup.rglob("*")):
    if path.is_file():
        add("cleanup/" + path.relative_to(cleanup).as_posix(), path)
add("plan/repair-plan.md", packet / "repair-plan.md")
add("plan/archive.py", Path(__file__))

patch = []
for name in ("README.md", "BROWSER-INGRESS-EVIDENCE.md", "ingress.py",
             "admission_test.py", "browser.cjs", "browser.py", "connect_guard.c", "connect_ledger.py"):
    target = name if name.endswith(".md") else "testdata/agent/" + name
    result = subprocess.run(["git", "show", "HEAD:" + target], cwd=repo, capture_output=True)
    before = result.stdout.decode() if result.returncode == 0 else ""
    after = (candidate / name).read_text()
    patch.extend(difflib.unified_diff(
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile="a/" + target if before else "/dev/null", tofile="b/" + target))
members["candidate/full-original-wip.patch"] = "".join(patch).encode()

secrets = read(remote / "browser/browser-config.json")["secrets"]
for name in ("connect.jsonl", "ingress.jsonl", "events.jsonl"):
    text = members["remote/browser/" + name].decode()
    assert '"headers"' not in text
    assert all(secret not in text for secret in secrets), name

receipt = {
    "status": "experimental admission WITHDRAWN; active baseline fail-closed; browser RED",
    "moduleBaseline": "9bec47b033405414bfa761e639d3a77f19b84d2d",
    "remoteRoot": "/tmp/magpie-zcode-ingress-admission-f7-rgsG8ph9",
    "originalReview": "CHANGES REQUESTED: unused old proof does not bind accepted TCP incarnation",
    "activeIngressSHA256": baseline,
    "authCause": "unknown; no core request-start, failure, message-on-failure or native timing evidence",
    "browser": read(remote / "browser/result.json"),
    "browserError": read(remote / "browser/browser-error.json"),
    "browserNotReplayed": True,
    "historicalThreeSendersRemainUnknown": True,
    "retainedFdProtocolImplemented": False,
    "unusedResetRegressionDraftExecuted": False,
    "cleanup": {name: read(cleanup / (name + "-result.json")) for name in (
        "cleanup-final", "old-cleanup-final", "active-boundary", "active-boundary-final")},
    "cleanupLimit": "original inherited process group only; separate PGID/SID escapes are not covered",
    "fullPrivateDownloadSHA256": digest((packet / "preserved-remote-packet.tar.gz").read_bytes()),
    "privateFilesNotCommitted": sorted(private),
    "compiledArtifactsNotCommittedSHA256": {
        name: digest((remote / name).read_bytes()) for name in sorted(compiled)},
    "newProductionBuilds": 0,
    "newBrowserCasesAfterRed": 0,
}
members["closure/receipt.json"] = (json.dumps(receipt, sort_keys=True, indent=2) + "\n").encode()

with archive.open("wb") as output:
    with gzip.GzipFile(fileobj=output, mode="wb", filename="", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as stream:
            for name, body in sorted(members.items()):
                item = tarfile.TarInfo(name)
                item.size = len(body)
                item.mode = 0o644
                stream.addfile(item, io.BytesIO(body))
with tarfile.open(archive, "r:gz") as stream:
    restored = {item.name: stream.extractfile(item).read() for item in stream.getmembers()}
assert restored == members
inventory = {name: digest(body) for name, body in sorted(members.items())}
manifest.write_text(json.dumps({
    "archive": archive.name, "archiveSHA256": digest(archive.read_bytes()),
    "status": receipt["status"], "memberCount": len(members), "membersSHA256": inventory,
    "activeIngressSHA256": baseline, "originalReviewVerdict": "CHANGES REQUESTED",
    "unusedResetRegressionDraftExecuted": False,
    "browserResult": {"exit": 1, "seconds": 17.02, "authCause": "unknown"},
}, sort_keys=True, indent=2) + "\n")
print(json.dumps({"archiveSHA256": digest(archive.read_bytes()),
                  "manifestSHA256": digest(manifest.read_bytes()),
                  "members": len(members), "bytes": archive.stat().st_size}))
