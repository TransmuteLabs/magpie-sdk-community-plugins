2026-11-14 bounded fixture repair plan

Preserve the current eight-file WIP, exact unsafe candidate, independent
review and all historical RED artifacts before changing fixture source.
Production/package/native/SDK bytes remain unchanged.

The user's subsequent closure instruction accepts archival rather than a new
held-FD protocol. Choose that smaller boundary; do not implement the proposal.

1. Archive the exact eight-file candidate, the separately added unused-reset
   regression draft (not executed), diffs, review and raw RED/gate evidence.
   Verify every archive member and both candidate variants by SHA256.
2. Restore active ingress.py byte-identical to HEAD9bec47b. Move experimental
   ledger/guard/admission/browser code out of active fixture paths; preserve
   their exact bytes in the archive. Keep unknown ingress a hard error.
3. Add a small explicit fixture command wrapper with an owned process session
   and bounded TERM/KILL/join teardown. Exercise it only with synthetic owned
   guard/child processes, an unrelated control and an old-cleanup negative.
   The archived unsafe browser runner is never executed or called by it.
4. Freeze the exact diff for Godel source review. Correct README and the evidence
   document: unsafe admission is withdrawn, browser auth17.02 remains RED,
   console/request traces were not captured and its cause remains unproven.
5. Commit only the reviewed synthetic archive, restored boundary, tested cleanup
   wrapper and honest docs using Lore. Preserve remote originals and local full
   evidence. No browser replay, host/native/package rebuild or later-host claim.
