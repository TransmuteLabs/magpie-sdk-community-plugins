from contextlib import ExitStack
import http.client,json,os,ssl,tempfile
from pathlib import Path
from host_e2e import certificate,Fixture,VIDEO,require
root=Path(__file__).resolve().parent
with ExitStack() as stack:
 home=Path(stack.enter_context(tempfile.TemporaryDirectory(prefix='fixture-smoke-',dir=root)))
 ca,context=certificate(home,dict(HOME=str(home),PATH='/usr/bin:/bin',LANG='C.UTF-8'))
 fixture=Fixture(context).start(stack)
 client=http.client.HTTPSConnection('127.0.0.1',fixture.server_port,context=ssl.create_default_context(cafile=str(ca)),timeout=5)
 try:
  client.set_tunnel('93.184.216.34',443)
  client.request('GET','/fixture.mp4')
  response=client.getresponse()
  require(response.status==200 and response.read()==VIDEO,'TLS video transfer mismatch')
 finally:client.close()
 denied=http.client.HTTPConnection('127.0.0.1',fixture.server_port,timeout=5)
 try:
  denied.request('CONNECT','vendor.example.invalid:443')
  response=denied.getresponse()
  require(response.status==502,'foreign CONNECT did not fail closed')
  response.read()
 finally:denied.close()
require(not fixture.connections and not fixture.failures,'fixture leaked or failed')
require(fixture.denied==['vendor.example.invalid:443'],'allowlist result mismatch')
print(json.dumps({'tlsPrivateCATrust':True,'credentialFreeMediaBytes':True,'unknownCONNECTDenied':True,'fixtureThreadsJoined':True}))
