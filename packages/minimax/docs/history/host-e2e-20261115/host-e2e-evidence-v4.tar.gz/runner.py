from pathlib import Path
import json,os,sys,subprocess,tempfile,time,hashlib,signal
r=Path(__file__).resolve().parent
if len(sys.argv)==2:
 os.execv('/usr/bin/python3',['python3','/tmp/magpie-astra-combined-20261115-v4/magpie-verification-network.py',str(r/(sys.argv[1]+'-network.json')),'python3',str(__file__),sys.argv[1],'guarded'])
mode=sys.argv[1];home=Path(tempfile.mkdtemp(prefix='mm-env-',dir=r))
env=dict(HOME=str(home),USERPROFILE=str(home),PATH='/usr/bin:/bin',LANG='C.UTF-8',TMPDIR=str(home),PYTHONDONTWRITEBYTECODE='1',GOPROXY='off',GOSUMDB='off',GOTOOLCHAIN='local',GOENV='off',GOTELEMETRY='off')
for k in ['XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','XDG_STATE_HOME','XDG_CONFIG_DIRS','XDG_DATA_DIRS','APPDATA','LOCALAPPDATA']:env[k]=str(home/k)
if mode.startswith('syntax'):cmd=['python3','-c',"import ast;ast.parse(open('host_e2e.py').read());print('syntax ok')"]
elif mode.startswith('fixture'):cmd=['python3','fixture_smoke.py']
else:cmd=['python3','host_e2e.py','--host','/tmp/magpie-monorepo-final-20261115/magpie','--distribution',str(r/'distribution-v4'),'--output',str(r/mode)]
if mode.startswith('classification'):cmd.append('--classification-only')
start=time.monotonic()
with (r/(mode+'.log')).open('w') as log:
 process=subprocess.Popen(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=process.wait(timeout=180)
 except subprocess.TimeoutExpired:
  os.killpg(process.pid,signal.SIGTERM)
  try:code=process.wait(timeout=30)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=5)
result={'mode':mode,'command':cmd,'exit':code,'seconds':time.monotonic()-start,'runnerSHA256':hashlib.sha256((r/'host_e2e.py').read_bytes()).hexdigest(),'home':str(home)}
(r/(mode+'-receipt.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((r/(mode+'.log')).read_text()[-3000:]);raise SystemExit(code)
